<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_ai_yared_course\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Detects and transcribes the exercises of a worksheet page with a vision model.
 *
 * Each detected exercise is returned as a normalised question, together with the bounding
 * boxes of the whole exercise and of its figure, so the caller can crop them.
 *
 * @package    local_ai_yared_course
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class exercise_extractor {

    /** Maximum number of exercises requested from one page. */
    public const MAX_PER_PAGE = 12;

    /** Maximum number of exercises accepted from a PDF. */
    public const MAX_PER_PDF = 20;

    /** Maximum number of answer options kept per question. */
    public const MAX_OPTIONS = 6;

    /** @var ai_client */
    protected $client;
    /** @var bool Whether questions keep LaTeX. */
    protected $mathmode;
    /** @var string[] */
    protected $warnings = [];

    /** @var int Exercises whose bounding boxes were missing in the last parse. */
    protected $missingboxes = 0;

    /**
     * Constructor.
     *
     * @param ai_client $client AI client.
     * @param bool $mathmode Keep LaTeX and line breaks in the generated text.
     */
    public function __construct(ai_client $client, bool $mathmode = true) {
        $this->client = $client;
        $this->mathmode = $mathmode;
    }

    /**
     * Warnings produced during the last extraction.
     *
     * @return string[]
     */
    public function get_warnings(): array {
        return $this->warnings;
    }

    /**
     * Extract the exercises of one page image.
     *
     * @param array $image Prepared image: ['data' => bytes, 'mimetype' => ...].
     * @param int $page Page number, used only to label the exercises.
     * @param string $language Language for the options and the feedback.
     * @param int $age Target age.
     * @param string $instructions Extra requirements from the teacher.
     * @return array[] Normalised exercises.
     * @throws \moodle_exception On AI or JSON errors.
     */
    public function extract_from_image(array $image, int $page, string $language, int $age,
            string $instructions = ''): array {
        $this->warnings = [];
        $this->missingboxes = 0;
        $system = $this->system_prompt();
        $prompt = $this->image_prompt($page, $language, $age, $instructions);
        $files = [[
            'mime' => $image['mimetype'] ?? 'image/jpeg',
            'data' => base64_encode((string) $image['data']),
        ]];
        $raw = $this->client->complete_multimodal($system, $prompt, $files);
        return $this->parse_with_retry($raw, $system, $prompt, $files, true, $page, self::MAX_PER_PAGE);
    }

    /**
     * Extract the exercises of a PDF (sent to the model as a document, without cropping).
     *
     * @param string $pdf PDF bytes.
     * @param string $language Language for the options and the feedback.
     * @param int $age Target age.
     * @param string $instructions Extra requirements from the teacher.
     * @return array[] Normalised exercises.
     * @throws \moodle_exception On AI or JSON errors.
     */
    public function extract_from_pdf(string $pdf, string $language, int $age, string $instructions = ''): array {
        $this->warnings = [];
        $this->missingboxes = 0;
        $system = $this->system_prompt();
        $prompt = $this->pdf_prompt($language, $age, $instructions);
        $files = [['mime' => 'application/pdf', 'data' => base64_encode($pdf)]];
        $raw = $this->client->complete_multimodal($system, $prompt, $files);
        return $this->parse_with_retry($raw, $system, $prompt, $files, false, 0, self::MAX_PER_PDF);
    }

    /**
     * Parse an answer and retry once when it was cut off or was not valid JSON.
     *
     * Providers occasionally cut a long JSON answer or return a malformed object. A second
     * request with the same files normally solves it; if the first answer was a valid empty
     * result, it is respected and no extra request is made.
     *
     * @param string $raw Raw answer of the first request.
     * @param string $system System prompt.
     * @param string $prompt User prompt.
     * @param array[] $files Attachments.
     * @param bool $allowboxes Whether bounding boxes are expected.
     * @param int $page Page number.
     * @param int $limit Maximum number of exercises.
     * @return array[] Normalised exercises.
     * @throws \moodle_exception When the second answer is also unusable.
     */
    protected function parse_with_retry(string $raw, string $system, string $prompt, array $files,
            bool $allowboxes, int $page, int $limit): array {
        try {
            $items = $this->parse($raw, $allowboxes, $page, $limit);
            if ($items) {
                // If the model returned the exercises but omitted every box, ask once more.
                if (!$allowboxes || $this->missingboxes < count($items)) {
                    return $items;
                }
            } else {
                $finish = strtoupper($this->client->get_last_finish_reason());
                if (!in_array($finish, ['MAX_TOKENS', 'LENGTH'], true)) {
                    return $items;
                }
            }
        } catch (\moodle_exception $e) {
            if (!in_array($e->errorcode, ['error_badjson', 'error_emptyresponse'], true)) {
                throw $e;
            }
        }

        // The first warnings described the unusable answer; they do not apply to the retry.
        $this->warnings = [];
        $retryprompt = $prompt . "\n\nIMPORTANT: The previous answer was incomplete or was not valid JSON. "
            . 'Return the complete JSON object again for the same file. Do not omit any exercise, do not '
            . 'stop in the middle and keep every feedback short.';
        if ($allowboxes) {
            $retryprompt .= ' Every exercise must include "exercise_box" and "figure_box" (or null). '
                . 'Write each box as [left, top, right, bottom] with left < right and top < bottom, using '
                . 'fractions of the image width and height. The exercise box must enclose the whole exercise.';
        }
        $raw = $this->client->complete_multimodal($system, $retryprompt, $files);
        return $this->parse($raw, $allowboxes, $page, $limit);
    }

    /**
     * System instructions shared by both prompts.
     *
     * @return string
     */
    protected function system_prompt(): string {
        return 'You are an expert teacher and assessment designer. You read photographs, scans and PDF '
            . 'documents of exercises and turn every exercise into a question for a Moodle question bank. '
            . 'You never invent exercises that are not on the page. You always reply with one single valid '
            . 'JSON object and nothing else.';
    }

    /**
     * Build the prompt used for one page image.
     *
     * @param int $page Page number.
     * @param string $language Output language for options and feedback.
     * @param int $age Target age.
     * @param string $instructions Extra requirements.
     * @return string
     */
    protected function image_prompt(int $page, string $language, int $age, string $instructions): string {
        $limit = self::MAX_PER_PAGE;
        $lines = [];
        $lines[] = "The attached image is page {$page} of a worksheet or an exam.";
        $lines[] = 'The page may be a scan, a photo or a collage of images. Read the whole page, including the text '
            . 'that appears inside images, tables and boxes.';
        $lines[] = 'First count every numbered exercise on the page (1, 2, 3...). Then detect every complete exercise '
            . "in reading order; the number of objects in \"exercises\" must match that count. Return at most {$limit} exercises.";
        $lines[] = 'Do not stop after the first exercise or after the first column. Continue to the bottom of the page.';
        $lines[] = 'For each exercise return:';
        $lines[] = '- "number": the printed label of the exercise as text ("9", "12.a", "3"...). Use "" when there is no label.';
        $lines[] = '- "text": the full statement, transcribed faithfully, including the instructions, the data and '
            . 'any sub-items a), b), c) that belong to the question itself. Do not solve it here and do not add '
            . 'anything that is not printed. Do NOT copy the answer options into "text": the printed alternatives '
            . '(a), b), c)... or A), B), C)...) go only in "options".';
        $lines[] = '- "type": "multichoice" when the exercise has printed answer options or when you must create '
            . 'them; "truefalse" only when the exercise asks to judge a statement as true or false.';
        $lines[] = '- "options": for "multichoice", the answer options in the printed order. If the exercise has no '
            . 'printed options, create exactly 4 plausible options. Each option is '
            . '{"text": "...", "correct": true or false}. Exactly one option must be correct. Distractors must be '
            . 'plausible and similar in length to the correct option. Never use "all of the above", '
            . '"none of the above" or "both".';
        $lines[] = '- "answer": for "truefalse", true or false.';
        $lines[] = '- "feedback": the worked solution, a short explanation of the correct answer with the key steps '
            . '(2 to 4 lines).';
        $lines[] = '- "correct_option": the letter (A, B, C...) of the correct option, counted in the printed order. '
            . 'Solve the exercise yourself first: work out the steps in "feedback" and only then choose the letter. '
            . 'The correct option can be in any position; never default to A. Always make the "correct": true flag '
            . 'of that option agree with this letter.';
        $lines[] = '- Write the keys in this order: number, text, type, feedback, options, correct_option, so the '
            . 'solution is worked out before the answer is chosen.';
        $lines[] = '- "exercise_box": [x0, y0, x1, y1], the box that tightly encloses the whole exercise, including '
            . 'its options, as fractions of the image width and height (0 = left/top, 1 = right/bottom). '
            . 'Always include it and always use x0 < x1 and y0 < y1.';
        $lines[] = '- "figure_box": [x0, y0, x1, y1] or null, the box that encloses only the drawing, diagram, '
            . 'graph or table that the exercise needs. Do not include the text of the statement. Use null when '
            . 'there is no figure. Always use x0 < x1 and y0 < y1.';
        $lines[] = '- "imagealt": a short description of the figure ("" when there is no figure).';
        $lines[] = '- "needs_figure": true when the exercise depends on a figure that is not enclosed by figure_box.';
        $lines[] = '- "page": ' . $page . '.';
        $lines[] = 'Rules:';
        $lines[] = '- Keep the original language of the worksheet. Write the answer options and the feedback in '
            . $language . '.';
        $lines[] = '- Write every mathematical expression in LaTeX: \\( ... \\) inline and \\[ ... \\] for display. '
            . 'Inside the JSON, write each LaTeX backslash twice.';
        $lines[] = '- Do not use Markdown, HTML, code fences or single-dollar delimiters.';
        $lines[] = '- Target audience: ' . question_generator::age_descriptor($age);
        $lines[] = '- Ignore headers, footers, page numbers, logos and instructions that are not part of an exercise.';
        $lines[] = '- Keep sub-items a), b), c) inside the same exercise; do not split them into separate exercises.';
        $lines[] = '- Do not merge two different exercises. Do not invent exercises. If the page has no exercises, '
            . 'return {"exercises": []}.';
        $lines[] = '- If the image is rotated, read it as if it were upright.';
        if ($instructions !== '') {
            $lines[] = '- Additional instructions from the teacher (follow them, but keep exactly the JSON shape): '
                . $instructions;
        }
        $lines[] = 'Reply with JSON in exactly this shape:';
        $lines[] = $this->example_json($page);
        return implode("\n", $lines);
    }

    /**
     * Build the prompt used for a PDF document.
     *
     * @param string $language Output language for options and feedback.
     * @param int $age Target age.
     * @param string $instructions Extra requirements.
     * @return string
     */
    protected function pdf_prompt(string $language, int $age, string $instructions): string {
        $limit = self::MAX_PER_PDF;
        $lines = [];
        $lines[] = 'The attached file is a PDF of a worksheet or an exam (at most 15 pages).';
        $lines[] = 'The PDF may be a scan, a photo or a composition of images. Read every page completely, including '
            . 'the text that appears inside images, tables and boxes.';
        $lines[] = 'First count every numbered exercise on every page (1, 2, 3...). Then detect all of them in reading '
            . "order; the number of objects in \"exercises\" must match that count. Return at most {$limit} exercises.";
        $lines[] = 'Do not stop after the first page or after the first exercises. Continue to the end of the document.';
        $lines[] = 'For each exercise return:';
        $lines[] = '- "number": the printed label of the exercise as text ("9", "12.a", "3"...). Use "" when there is no label.';
        $lines[] = '- "text": the full statement, transcribed faithfully, including the instructions, the data and '
            . 'any sub-items a), b), c). If the exercise depends on a figure, describe the figure briefly in square '
            . 'brackets at the end of the statement, for example "[Figura: triángulo rectángulo con catetos 3 y 4]". '
            . 'Do NOT copy the answer options into "text": the printed alternatives (a), b), c)... or A), B), C)...) '
            . 'go only in "options".';
        $lines[] = '- "type": "multichoice" when the exercise has printed answer options or when you must create '
            . 'them; "truefalse" only when the exercise asks to judge a statement as true or false.';
        $lines[] = '- "options": for "multichoice", the answer options in the printed order. If the exercise has no '
            . 'printed options, create exactly 4 plausible options. Each option is '
            . '{"text": "...", "correct": true or false}. Exactly one option must be correct. Never use '
            . '"all of the above", "none of the above" or "both".';
        $lines[] = '- "answer": for "truefalse", true or false.';
        $lines[] = '- "feedback": the worked solution, a short explanation of the correct answer with the key steps.';
        $lines[] = '- "correct_option": the letter (A, B, C...) of the correct option, counted in the printed order. '
            . 'Solve the exercise yourself first: work out the steps in "feedback" and only then choose the letter. '
            . 'The correct option can be in any position; never default to A. Always make the "correct": true flag '
            . 'of that option agree with this letter.';
        $lines[] = '- Write the keys in this order: number, text, type, feedback, options, correct_option, so the '
            . 'solution is worked out before the answer is chosen.';
        $lines[] = '- "needs_figure": true when the exercise depends on a figure that cannot be read from the text.';
        $lines[] = '- "page": the 1-based number of the PDF page where the exercise appears.';
        $lines[] = '- "exercise_box" and "figure_box": null. The PDF pages are not cropped.';
        $lines[] = 'Rules:';
        $lines[] = '- Keep the original language of the worksheet. Write the answer options and the feedback in '
            . $language . '.';
        $lines[] = '- Write every mathematical expression in LaTeX: \\( ... \\) inline and \\[ ... \\] for display. '
            . 'Inside the JSON, write each LaTeX backslash twice.';
        $lines[] = '- Do not use Markdown, HTML, code fences or single-dollar delimiters.';
        $lines[] = '- Target audience: ' . question_generator::age_descriptor($age);
        $lines[] = '- Keep sub-items a), b), c) inside the same exercise. Do not merge two different exercises.';
        $lines[] = '- Do not invent exercises. If the PDF has no exercises, return {"exercises": []}.';
        if ($instructions !== '') {
            $lines[] = '- Additional instructions from the teacher (follow them, but keep exactly the JSON shape): '
                . $instructions;
        }
        $lines[] = 'Reply with JSON in exactly this shape:';
        $lines[] = $this->example_json(1, true);
        return implode("\n", $lines);
    }

    /**
     * Compact JSON example included in the prompt.
     *
     * @param int $page Page number.
     * @param bool $ispdf Whether the example is for a PDF (no boxes).
     * @return string
     */
    protected function example_json(int $page, bool $ispdf = false): string {
        $math = $this->mathmode;
        $example = [
            'exercises' => [
                [
                    'number' => '9',
                    'text' => $math ? 'Resuelve \\(2x+3=11\\).' : 'Resuelve la ecuación 2x+3=11.',
                    'type' => 'multichoice',
                    'feedback' => $math ? 'Restamos 3: \\(2x=8\\). Dividimos entre 2: \\(x=4\\).'
                        : 'Restamos 3 y dividimos entre 2: x = 4.',
                    'options' => [
                        ['text' => $math ? '\\(x=7\\)' : 'x = 7', 'correct' => false],
                        ['text' => $math ? '\\(x=5\\)' : 'x = 5', 'correct' => false],
                        ['text' => $math ? '\\(x=4\\)' : 'x = 4', 'correct' => true],
                        ['text' => $math ? '\\(x=14\\)' : 'x = 14', 'correct' => false],
                    ],
                    'correct_option' => 'C',
                    'exercise_box' => $ispdf ? null : [0.05, 0.15, 0.95, 0.42],
                    'figure_box' => $ispdf ? null : [0.62, 0.2, 0.9, 0.4],
                    'imagealt' => 'Gráfico de una recta',
                    'needs_figure' => false,
                    'page' => $page,
                ],
                [
                    'number' => '12',
                    'text' => $math ? 'La suma de los ángulos internos de un triángulo es \\(180^\\circ\\).'
                        : 'La suma de los ángulos internos de un triángulo es 180 grados.',
                    'type' => 'truefalse',
                    'options' => [],
                    'answer' => true,
                    'feedback' => 'En todo triángulo euclidiano la suma de los ángulos internos es 180 grados.',
                    'exercise_box' => $ispdf ? null : [0.05, 0.5, 0.95, 0.7],
                    'figure_box' => null,
                    'imagealt' => '',
                    'needs_figure' => false,
                    'page' => $page,
                ],
            ],
        ];
        return json_encode($example, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Parse and normalise the model answer.
     *
     * @param string $raw Raw answer.
     * @param bool $allowboxes Whether the exercises may carry bounding boxes.
     * @param int $page Page number used for image pages.
     * @param int $limit Maximum number of exercises accepted.
     * @return array[] Normalised exercises.
     * @throws \moodle_exception When no usable JSON was returned.
     */
    protected function parse(string $raw, bool $allowboxes, int $page, int $limit): array {
        $this->missingboxes = 0;
        $data = ai_json::extract($raw, $this->mathmode);
        if ($data === null) {
            throw new \moodle_exception('error_badjson', 'local_ai_yared_course');
        }
        if (array_is_list($data)) {
            $items = $data;
        } else {
            $items = $data['exercises'] ?? $data['questions'] ?? $data['items'] ?? [];
        }
        if (!is_array($items)) {
            $items = [];
        }

        $exercises = [];
        $seen = [];
        $skipped = 0;
        $review = 0;
        $badboxes = 0;
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            if (count($exercises) >= $limit) {
                $this->warnings[] = get_string('import_warn_limit', 'local_ai_yared_course', $limit);
                break;
            }
            $exercise = $this->normalise($item, $allowboxes, $page, $review);
            if ($exercise === null) {
                $skipped++;
                continue;
            }
            if ($allowboxes && !$exercise['figure'] && !$exercise['exercise']) {
                $this->missingboxes++;
            }
            if (!$exercise['figure'] && !$exercise['exercise'] && $allowboxes
                    && (!empty($item['figure_box']) || !empty($item['exercise_box']))) {
                $badboxes++;
            }
            $key = \core_text::strtolower(\core_text::substr($exercise['text'], 0, 160));
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $exercises[] = $exercise;
        }

        if ($skipped > 0) {
            $this->warnings[] = get_string('import_warn_skipped', 'local_ai_yared_course', $skipped);
        }
        if ($review > 0) {
            $this->warnings[] = get_string('import_warn_review', 'local_ai_yared_course', $review);
        }
        if ($badboxes > 0) {
            $this->warnings[] = get_string('import_warn_boxes', 'local_ai_yared_course', $badboxes);
        }
        if (!$items) {
            $this->warnings[] = get_string('import_warn_none', 'local_ai_yared_course');
        }

        return $exercises;
    }

    /**
     * Remove the answer options when the model copied them at the end of the statement.
     *
     * The options already travel in their own field, so the statement keeps only the question. The block
     * is removed only when it starts with the label "a)" and contains the text of at least two of the
     * options, so sub-items a), b) that belong to the question itself are left alone.
     *
     * @param string $text Statement.
     * @param array $options Normalised options ([['text' => ..., 'correct' => ...], ...]).
     * @return string Statement without the options.
     */
    protected function strip_options_from_text(string $text, array $options): string {
        if (count($options) < 2) {
            return $text;
        }
        // Models sometimes write a literal "\n" (backslash + n) before each option label.
        $work = preg_replace('/\\\\n(?=\s*\(?[A-Fa-f]\s*[\)\.])/u', "\n", $text);
        $label = '/(?<![\p{L}\p{N}])\(?([A-Fa-f])\s*[\)\.](?=\s)/u';
        if (!preg_match_all($label, $work, $matches, PREG_OFFSET_CAPTURE) || count($matches[0]) < 2) {
            return $text;
        }
        $normalise = function (string $value): string {
            return preg_replace('/[\s\\\\()\[\]$]+/u', '', \core_text::strtolower($value));
        };
        $needed = min(2, count($options));

        // Try the last "a)" first: the options come after the question.
        for ($k = count($matches[0]) - 1; $k >= 0; $k--) {
            if (\core_text::strtolower($matches[1][$k][0]) !== 'a') {
                continue;
            }
            $cut = $matches[0][$k][1];
            $tail = substr($work, $cut);
            $head = rtrim(substr($work, 0, $cut));
            if ($head === '' || !preg_match('/(?<![\p{L}\p{N}])\(?[Bb]\s*[\)\.](?=\s)/u', $tail)) {
                continue;
            }
            $normalisedtail = $normalise($tail);
            $found = 0;
            foreach ($options as $option) {
                $needle = $normalise((string) $option['text']);
                if ($needle !== '' && strpos($normalisedtail, $needle) !== false) {
                    $found++;
                }
            }
            if ($found >= $needed) {
                return $head;
            }
        }
        return $text;
    }

    /**
     * Validate one exercise and convert it to the internal structure.
     *
     * @param array $item Raw exercise.
     * @param bool $allowboxes Whether bounding boxes are expected.
     * @param int $page Page number for image pages.
     * @param int $review Counter of exercises that need the teacher to confirm the answer (by reference).
     * @return array|null Normalised exercise, or null when it cannot be used.
     */
    protected function normalise(array $item, bool $allowboxes, int $page, int &$review): ?array {
        $text = $this->clean((string) ($item['text'] ?? $item['statement'] ?? $item['question'] ?? ''));
        if ($text === '') {
            return null;
        }
        if (\core_text::strlen($text) > 5000) {
            $text = \core_text::substr($text, 0, 5000);
        }

        $options = [];
        foreach ((array) ($item['options'] ?? []) as $option) {
            if (is_string($option)) {
                $option = ['text' => $option];
            }
            if (!is_array($option)) {
                continue;
            }
            $otext = $this->clean((string) ($option['text'] ?? $option['label'] ?? ''));
            $otext = trim((string) preg_replace('/^\s*[A-Fa-f1-6][\)\.\:]\s+/u', '', $otext));
            if ($otext === '') {
                continue;
            }
            if (\core_text::strlen($otext) > 1000) {
                $otext = \core_text::substr($otext, 0, 1000);
            }
            $correct = false;
            if (isset($option['correct'])) {
                $correct = is_string($option['correct'])
                    ? in_array(\core_text::strtolower(trim($option['correct'])),
                        ['true', '1', 'yes', 'si', 'sí', 'verdadero'], true)
                    : (bool) $option['correct'];
            }
            $options[] = ['text' => $otext, 'correct' => $correct];
            if (count($options) >= self::MAX_OPTIONS) {
                break;
            }
        }

        $type = \core_text::strtolower(trim((string) ($item['type'] ?? '')));
        $answer = null;
        if (isset($item['answer'])) {
            if (is_bool($item['answer'])) {
                $answer = $item['answer'];
            } else {
                $answer = in_array(\core_text::strtolower(trim((string) $item['answer'])),
                    ['true', '1', 'yes', 'si', 'sí', 'verdadero', 'v'], true);
            }
        }
        $istruefalse = in_array($type, ['truefalse', 'true_false', 'true-false', 'tf', 'boolean', 'verdadero_falso'],
            true) && !$options;

        $figurebox = $allowboxes ? crop_helper::normalise_box($item['figure_box'] ?? null) : null;
        $exercisebox = $allowboxes ? crop_helper::normalise_box($item['exercise_box'] ?? null) : null;
        // A real exercise spans a meaningful part of the page. Reject a narrow strip that some
        // models return when they confuse the x/y order; the teacher can still draw the crop.
        if ($exercisebox !== null && ($exercisebox[2] - $exercisebox[0]) < 0.08) {
            $exercisebox = null;
        }

        if ($istruefalse) {
            $needsreview = false;
            if ($answer === null) {
                $answer = false;
                $needsreview = true;
                $review++;
            }
            return [
                'number' => \core_text::substr(trim((string) ($item['number'] ?? '')), 0, 20),
                'text' => $text,
                'type' => 'truefalse',
                'answer' => $answer,
                'options' => [],
                'feedback' => \core_text::substr($this->clean((string) ($item['feedback'] ?? '')), 0, 4000),
                'figure' => $figurebox,
                'exercise' => $exercisebox,
                'imagealt' => \core_text::substr(trim((string) ($item['imagealt'] ?? '')), 0, 250),
                'needsfigure' => !empty($item['needs_figure']),
                'needsreview' => $needsreview,
                'page' => $allowboxes ? $page : max(0, (int) ($item['page'] ?? 0)),
                'math' => $this->mathmode,
            ];
        }

        if (count($options) < 2) {
            return null;
        }
        // The options must not stay inside the statement as well.
        $text = $this->strip_options_from_text($text, $options);

        // Letter of the correct option, as an independent answer next to the per-option flags.
        $letterindex = -1;
        $rawletter = $item['correct_option'] ?? $item['correct_letter'] ?? null;
        if (is_string($rawletter) && preg_match('/^\s*\(?([A-Fa-f])\b/u', $rawletter, $lettermatch)
                && ord(strtoupper($lettermatch[1])) - 65 < count($options)) {
            $letterindex = ord(strtoupper($lettermatch[1])) - 65;
        }

        $correctcount = 0;
        $firstcorrect = -1;
        foreach ($options as $index => $option) {
            if ($option['correct']) {
                $correctcount++;
                if ($firstcorrect < 0) {
                    $firstcorrect = $index;
                }
            }
        }
        $needsreview = false;
        if ($correctcount !== 1) {
            // The flags are missing or ambiguous: use the letter if the model gave one. Only when there is
            // no usable answer does the first option stay selected, and the teacher must confirm it.
            $chosen = $letterindex >= 0 ? $letterindex : ($firstcorrect >= 0 ? $firstcorrect : 0);
            foreach ($options as $index => $option) {
                $options[$index]['correct'] = ($index === $chosen);
            }
            if ($letterindex < 0) {
                $needsreview = true;
                $review++;
            }
        } else if ($letterindex >= 0 && $letterindex !== $firstcorrect) {
            // The flag and the letter disagree: keep the flag but ask the teacher to check.
            $needsreview = true;
            $review++;
        }

        return [
            'number' => \core_text::substr(trim((string) ($item['number'] ?? '')), 0, 20),
            'text' => $text,
            'type' => 'multichoice',
            'answer' => null,
            'options' => $options,
            'feedback' => \core_text::substr($this->clean((string) ($item['feedback'] ?? '')), 0, 4000),
            'figure' => $figurebox,
            'exercise' => $exercisebox,
            'imagealt' => \core_text::substr(trim((string) ($item['imagealt'] ?? '')), 0, 250),
            'needsfigure' => !empty($item['needs_figure']),
            'needsreview' => $needsreview,
            'page' => $allowboxes ? $page : max(0, (int) ($item['page'] ?? 0)),
            'math' => $this->mathmode,
        ];
    }

    /**
     * Strip tags and normalise whitespace without destroying LaTeX.
     *
     * @param string $text Text.
     * @return string
     */
    protected function clean(string $text): string {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        if (!$this->mathmode) {
            $text = strip_tags($text);
        }
        $text = preg_replace('/[ \t]+/u', ' ', $text);
        $text = preg_replace('/\n{3,}/u', "\n\n", $text);
        return trim((string) $text);
    }
}
