<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for local_ai_yared_course.
 *
 * @package    local_ai_yared_course
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the plugin.
 *
 * @param int $oldversion The old version of the plugin.
 * @return bool
 */
function xmldb_local_ai_yared_course_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    if ($oldversion < 2026101902) {
        // Define table local_ai_yared_course_topic to be created.
        $table = new xmldb_table('local_ai_yared_course_topic');

        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('title', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('summary', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('classdate', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('sectionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('sectionnum', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_index('courseid', XMLDB_INDEX_NOTUNIQUE, ['courseid']);
        $table->add_index('courseid-sortorder', XMLDB_INDEX_NOTUNIQUE, ['courseid', 'sortorder']);

        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026101902, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102001) {
        // The former AI question bank activity was merged into this plugin: no schema change.
        upgrade_plugin_savepoint(true, 2026102001, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102002) {
        // Gemini 2.5 Flash is no longer available to new users: the default is now 3.8 Flash.
        upgrade_plugin_savepoint(true, 2026102002, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102003) {
        // Each designed topic can now have its own audience age (0 = use the global level).
        $table = new xmldb_table('local_ai_yared_course_topic');
        $field = new xmldb_field('age', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '0', 'summary');

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2026102003, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102005) {
        // Main AI provider plus two optional fallbacks: settings only, no schema change.
        upgrade_plugin_savepoint(true, 2026102005, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102006) {
        // The internal topic designer is no longer linked from the course menu: no schema change.
        upgrade_plugin_savepoint(true, 2026102006, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102007) {
        // Rename the external service display name; the shortname and the app integration do not change.
        $service = $DB->get_record('external_services', ['shortname' => 'local_ai_yared_course']);
        if ($service && trim($service->name) === 'AI Yared Course') {
            $service->name = 'Yared.AI Creador de Material';
            $service->timemodified = time();
            $DB->update_record('external_services', $service);
        }

        // Rename the bank links already created inside courses, keeping their topic suffix.
        $select = $DB->sql_like('name', ':oldes', false) . ' OR ' . $DB->sql_like('name', ':olden', false);
        $urls = $DB->get_records_select('url', $select, [
            'oldes' => 'Banco de preguntas IA:%',
            'olden' => 'AI question bank:%',
        ]);
        foreach ($urls as $url) {
            if (strpos((string) $url->externalurl, '/question/edit.php') === false) {
                continue;
            }
            if (strpos($url->name, 'Banco de preguntas IA: ') === 0) {
                $url->name = 'Yared.AI Creador de Pregunta: ' . substr($url->name, strlen('Banco de preguntas IA: '));
            } else if (strpos($url->name, 'AI question bank: ') === 0) {
                $url->name = 'Yared.AI Question Creator: ' . substr($url->name, strlen('AI question bank: '));
            } else {
                continue;
            }
            $url->timemodified = time();
            $DB->update_record('url', $url);
        }

        upgrade_plugin_savepoint(true, 2026102007, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102008) {
        // Waiting view for the question generator: no schema change.
        upgrade_plugin_savepoint(true, 2026102008, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102009) {
        // LaTeX and image support for generated questions: no schema change.
        upgrade_plugin_savepoint(true, 2026102009, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102010) {
        // Optional statement image upload: form and file storage only, no schema change.
        upgrade_plugin_savepoint(true, 2026102010, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102011) {
        // PDF/image question importer: temporary files live in the user context, no schema change.
        upgrade_plugin_savepoint(true, 2026102011, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102012) {
        // Three creation modes and the crop editor: no schema change.
        upgrade_plugin_savepoint(true, 2026102012, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102013) {
        // Gemini 3.7 Flash can take more than three minutes for a tiny request. Use the fast lite
        // model by default and give slow multimodal requests the recommended 10-minute timeout.
        $cfg = get_config('local_ai_yared_course');
        if (!$cfg) {
            $cfg = new \stdClass();
        }
        foreach (['model', 'model_2', 'model_3'] as $modelkey) {
            if (($cfg->{$modelkey} ?? '') === 'gemini-3.7-flash') {
                set_config($modelkey, 'gemini-3.5-flash-lite', 'local_ai_yared_course');
            }
        }
        if (isset($cfg->timeout) && (int) $cfg->timeout === 180) {
            set_config('timeout', 600, 'local_ai_yared_course');
        }
        upgrade_plugin_savepoint(true, 2026102013, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102014) {
        // PDF pages can be rasterised and cropped; batches now accept up to 10 source images.
        // Settings and temporary files only, no schema change.
        upgrade_plugin_savepoint(true, 2026102014, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102015) {
        // Scheduled task to clean abandoned imports, a real privacy provider and the topic_generated event:
        // no schema change.
        upgrade_plugin_savepoint(true, 2026102015, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102016) {
        // More robust PDF rendering (retry, clean helper output) and visible error code: no schema change.
        upgrade_plugin_savepoint(true, 2026102016, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102017) {
        // PDF renderer picks a Python that really has PyMuPDF; shorter text-only notice: no schema change.
        upgrade_plugin_savepoint(true, 2026102017, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102018) {
        // Importer: the model returns the letter of the correct option and solves before answering: no schema change.
        upgrade_plugin_savepoint(true, 2026102018, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102019) {
        // Admin page shows the PDF conversion status (Docker or regular server): no schema change.
        upgrade_plugin_savepoint(true, 2026102019, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102020) {
        // PyMuPDF status check in Site administration > Reports > Status and a notice after installing: no schema change.
        \local_ai_yared_course\local\pdf_renderer::notify_if_missing();
        upgrade_plugin_savepoint(true, 2026102020, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102021) {
        // The installation commands for PyMuPDF are now shown in the notice, the status check and the settings.
        upgrade_plugin_savepoint(true, 2026102021, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102022) {
        // Importer: options removed from the statement and a preview button in the review: no schema change.
        upgrade_plugin_savepoint(true, 2026102022, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102023) {
        // The LaTeX typesetting of the review preview receives a jQuery object, as the filters API expects: no schema change.
        upgrade_plugin_savepoint(true, 2026102023, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102024) {
        // Five AI backups, more providers, optional PDF, one-page quiz and discussion forum: no schema change.
        upgrade_plugin_savepoint(true, 2026102024, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102025) {
        // Background jobs table.
        $dbman = $DB->get_manager();
        $table = new xmldb_table('local_ai_yared_course_job');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'queued');
        $table->add_field('cancelreq', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('total', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('done', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('failed', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('step', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('log', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('options', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('results', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('error', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timefinished', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_index('userid-courseid', XMLDB_INDEX_NOTUNIQUE, ['userid', 'courseid']);
        $table->add_index('status', XMLDB_INDEX_NOTUNIQUE, ['status']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026102025, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102026) {
        // Topic index at the top of existing sections: no schema change.
        upgrade_plugin_savepoint(true, 2026102026, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102027) {
        // Topics as collapsed subsections (Moodle 5 / Flexsections): no schema change.
        upgrade_plugin_savepoint(true, 2026102027, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102028) {
        // FlexTiles: topics created in an existing section become accordion subsections by default.
        // The change is resolved at runtime from the course format; no schema change.
        upgrade_plugin_savepoint(true, 2026102028, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102029) {
        // FlexTiles: remove an orphan section when the format cannot attach it to the chosen parent.
        // No schema change.
        upgrade_plugin_savepoint(true, 2026102029, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102230) {
        // Quiz wizard: creates a standard mod_quiz from one or more question banks.
        // No schema change.
        upgrade_plugin_savepoint(true, 2026102230, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102231) {
        // Quiz wizard: show FlexTiles/Flexsections subsections in the placement list.
        // No schema change.
        upgrade_plugin_savepoint(true, 2026102231, 'local', 'ai_yared_course');
    }

    if ($oldversion < 2026102232) {
        // Use the visible name Formato-Mariategui in course-format messages.
        // No schema change.
        upgrade_plugin_savepoint(true, 2026102232, 'local', 'ai_yared_course');
    }

    return true;
}
