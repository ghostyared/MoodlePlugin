<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Question importer: reads exercises from PDFs and photos, lets the teacher review them and
 * saves them in the course question bank.
 *
 * @package    local_ai_yared_course
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/questionlib.php');

use local_ai_yared_course\form\generate_form;
use local_ai_yared_course\form\import_form;
use local_ai_yared_course\local\ai_factory;
use local_ai_yared_course\local\category_helper;
use local_ai_yared_course\local\crop_helper;
use local_ai_yared_course\local\exercise_extractor;
use local_ai_yared_course\local\import_store;
use local_ai_yared_course\local\pdf_renderer;
use local_ai_yared_course\local\question_saver;
use local_ai_yared_course\local\source_reader;

$id = required_param('id', PARAM_INT);
$course = get_course($id);
require_login($course);

$context = context_course::instance($course->id);
require_capability('local/ai_yared_course:use', $context);
require_capability('moodle/question:add', $context);

$PAGE->set_url('/local/ai_yared_course/import.php', ['id' => $course->id]);
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('import_title', 'local_ai_yared_course'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->requires->css(new moodle_url('/local/ai_yared_course/styles.css'));

$client = ai_factory::create();
if (!$client->is_configured()) {
    echo $OUTPUT->header();
    if (has_capability('moodle/site:config', context_system::instance())) {
        $url = new moodle_url('/admin/settings.php', ['section' => 'local_ai_yared_course']);
        echo $OUTPUT->notification(get_string('notconfigured_admin', 'local_ai_yared_course', $url->out()), 'warning');
    } else {
        echo $OUTPUT->notification(get_string('notconfigured_teacher', 'local_ai_yared_course'), 'warning');
    }
    echo $OUTPUT->footer();
    exit;
}

$cancreatecategory = has_capability('moodle/question:managecategory', $context);
$categories = category_helper::get_options($context);
$bankurl = new moodle_url('/local/ai_yared_course/bank.php', ['id' => $course->id]);
$action = optional_param('action', '', PARAM_ALPHA);
$errors = [];
$warnings = [];
$manifest = null;
$posted = null;
$formdata = null;
$showform = true;
$reviewdraft = 0;

// Preview of one question of the review screen, rendered like the saved question (LaTeX included).
if ($action === 'preview') {
    require_sesskey();
    $scalar = function ($value): string {
        return is_scalar($value) ? (string) $value : '';
    };
    $limit = function (string $value, int $max): string {
        $value = trim(clean_param($value, PARAM_RAW));
        return \core_text::strlen($value) > $max ? \core_text::substr($value, 0, $max) : $value;
    };
    $previewtype = $scalar($_POST['type'] ?? '') === 'truefalse' ? 'truefalse' : 'multichoice';
    $previewq = [
        'type' => $previewtype,
        'text' => $limit($scalar($_POST['text'] ?? ''), 5000),
        'feedback' => $limit($scalar($_POST['feedback'] ?? ''), 4000),
        'math' => true,
        'options' => [],
        'answer' => null,
    ];
    if ($previewtype === 'truefalse') {
        $answerraw = $scalar($_POST['answer'] ?? '');
        $previewq['answer'] = in_array($answerraw, ['0', '1'], true) ? $answerraw === '1' : null;
    } else {
        $correctindex = (int) $scalar($_POST['correct'] ?? '-1');
        $postedpreview = is_array($_POST['options'] ?? null) ? $_POST['options'] : [];
        foreach ($postedpreview as $index => $optiontext) {
            $optiontext = $limit($scalar($optiontext), 1000);
            if ($optiontext === '') {
                continue;
            }
            $previewq['options'][] = ['text' => $optiontext, 'correct' => ((int) $index === $correctindex)];
        }
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(question_saver::render_preview($previewq, $context), JSON_UNESCAPED_UNICODE);
    die();
}

// Discard a pending import.
if ($action === 'discard') {
    require_sesskey();
    $draftid = required_param('draft', PARAM_INT);
    import_store::delete($draftid, $USER->id);
    redirect($bankurl, get_string('import_discarded', 'local_ai_yared_course'), null,
        \core\output\notification::NOTIFY_INFO);
}

// Analyse the uploaded files.
if ($action === 'extract') {
    $mform = new import_form($PAGE->url->out(false), [
        'courseid' => $course->id,
        'categories' => $categories,
        'cancreatecategory' => $cancreatecategory,
    ]);
    if ($mform->is_cancelled()) {
        redirect($bankurl);
    }
    $formdata = $mform->get_data();
    if ($formdata) {
        require_sesskey();
        core_php_time_limit::raise(900);
        raise_memory_limit(MEMORY_EXTRA);
        // Release the session lock during the long AI call.
        \core\session\manager::write_close();

        $draftid = null;
        try {
            $sources = source_reader::read_draft_files((int) $formdata->sources);
            $language = generate_form::LANGUAGES[$formdata->language] ?? 'Spanish';
            $age = generate_form::resolve_age($formdata->level, (int) $formdata->age);
            $instructions = trim((string) ($formdata->instructions ?? ''));
            $attachimage = !empty($formdata->attachimage);
            $categoryid = (int) $formdata->categoryid;
            $newcategory = $categoryid === 0 ? trim((string) ($formdata->newcategory ?? '')) : '';
            if ($categoryid === 0 && $newcategory === '') {
                throw new \moodle_exception('err_newcategory', 'local_ai_yared_course');
            }

            $draftid = import_store::create($USER->id, [
                'version' => 1,
                'userid' => $USER->id,
                'courseid' => $course->id,
                'timecreated' => time(),
                'categoryid' => $categoryid,
                'newcategory' => $newcategory,
                'language' => $formdata->language,
                'level' => $formdata->level,
                'age' => $age,
                'math' => true,
                'attachimage' => $attachimage,
                'sources' => [],
                'exercises' => [],
                'warnings' => [],
            ]);

            // A low temperature keeps the transcription faithful to the page.
            $client->set_temperature(0.2);
            $extractor = new exercise_extractor($client, true);
            $exercises = [];
            $seen = [];
            $sourcesummary = [];
            $duplicates = 0;
            $noimage = 0;
            $limited = false;
            $page = 0;

            // Add the exercises of one page, removing duplicates and preparing its crops.
            $additems = function(array $items, ?array $prepared, ?string $sourcefile) use (
                &$exercises, &$seen, &$duplicates, &$noimage, &$limited, $attachimage, $draftid, $USER
            ): void {
                foreach ($items as $item) {
                    if (count($exercises) >= exercise_extractor::MAX_PER_PDF) {
                        $limited = true;
                        break;
                    }
                    $key = sha1(\core_text::strtolower(trim((string) preg_replace('/\s+/u', ' ', $item['text']))));
                    if (isset($seen[$key])) {
                        $duplicates++;
                        continue;
                    }
                    $seen[$key] = true;

                    $item['image'] = null;
                    $item['useimage'] = false;
                    $box = !empty($item['figure']) ? $item['figure'] : ($item['exercise'] ?? null);
                    $item['sourcefile'] = $sourcefile;
                    $item['box'] = $box;
                    if ($prepared !== null && $attachimage && $box) {
                        $crop = crop_helper::crop($prepared['data'], $box);
                        if ($crop !== null) {
                            $extension = $crop['mimetype'] === 'image/png' ? 'png' : 'jpg';
                            $filename = 'q' . (count($exercises) + 1) . '-'
                                . (!empty($item['figure']) ? 'figure' : 'exercise') . '.' . $extension;
                            $item['image'] = import_store::add_file($draftid, $USER->id, $filename,
                                $crop['data'], $crop['mimetype']);
                            $item['useimage'] = true;
                            if ($item['imagealt'] === '') {
                                $item['imagealt'] = get_string('image_default_alt', 'local_ai_yared_course');
                            }
                        } else {
                            $noimage++;
                        }
                    } else if ($prepared !== null && $attachimage && !$box) {
                        $noimage++;
                    }
                    $exercises[] = $item;
                }
            };

            foreach ($sources as $source) {
                if (count($exercises) >= exercise_extractor::MAX_PER_PDF) {
                    $limited = true;
                    break;
                }
                try {
                    if ($source['type'] === 'pdf' && !$client->supports_pdf()) {
                        $warnings[] = get_string('import_warn_nopdf', 'local_ai_yared_course', s($source['filename']));
                        continue;
                    }

                    if ($source['type'] === 'pdf') {
                        // Convert the PDF pages to images so the exercises can be cropped too.
                        $rendered = pdf_renderer::render($source['content']);
                        if ($rendered) {
                            $summary = [
                                'filename' => $source['filename'],
                                'type' => 'pdf',
                                'pages' => count($rendered),
                                'pagefile' => null,
                                'pagenumber' => 0,
                            ];
                            foreach ($rendered as $paged) {
                                if (count($exercises) >= exercise_extractor::MAX_PER_PDF) {
                                    $limited = true;
                                    break;
                                }
                                try {
                                    $page++;
                                    $prepared = source_reader::prepare_image($paged['data']);
                                    // Keep the working page so the teacher can adjust the crop during the review.
                                    $sourcefile = import_store::add_file($draftid, $USER->id, 'source-' . $page . '.jpg',
                                        $prepared['data'], $prepared['mimetype']);
                                    if ($summary['pagefile'] === null) {
                                        $summary['pagefile'] = $sourcefile;
                                        $summary['pagenumber'] = $page;
                                    }
                                    $items = $extractor->extract_from_image($prepared, $page, $language, $age,
                                        $instructions);
                                    $warnings = array_merge($warnings, $extractor->get_warnings());
                                    $additems($items, $prepared, $sourcefile);
                                } catch (\moodle_exception $e) {
                                    $warnings[] = get_string('import_warn_pagefailed', 'local_ai_yared_course', (object) [
                                        'file' => s($source['filename']),
                                        'page' => $page,
                                        'error' => $e->getMessage(),
                                    ]);
                                }
                                unset($prepared);
                            }
                            $sourcesummary[] = $summary;
                            continue;
                        }

                        // No rasteriser: keep the old text-only PDF path and warn about the missing crops.
                        if (pdf_renderer::get_last_error() !== '') {
                            $renderdetail = pdf_renderer::get_last_error();
                            if (pdf_renderer::get_last_detail() !== ''
                                    && has_capability('moodle/site:config', context_system::instance())) {
                                $renderdetail .= ': ' . pdf_renderer::get_last_detail();
                            }
                            $warnings[] = get_string('import_warn_pdfrender', 'local_ai_yared_course', s($renderdetail));
                        }
                        $items = $extractor->extract_from_pdf($source['content'], $language, $age, $instructions);
                        $warnings = array_merge($warnings, $extractor->get_warnings());
                        $sourcesummary[] = [
                            'filename' => $source['filename'],
                            'type' => 'pdf',
                            'pages' => (int) ($source['pages'] ?? 0),
                            'pagefile' => null,
                            'pagenumber' => 0,
                        ];
                        $additems($items, null, null);
                        $page += max(1, (int) ($source['pages'] ?? 0));
                        continue;
                    }

                    $prepared = source_reader::prepare_image($source['content']);
                    $page++;
                    // Keep the working page so the teacher can adjust or redraw crops during the review.
                    $sourcefile = import_store::add_file($draftid, $USER->id, 'source-' . $page . '.jpg',
                        $prepared['data'], $prepared['mimetype']);
                    $items = $extractor->extract_from_image($prepared, $page, $language, $age, $instructions);
                    $warnings = array_merge($warnings, $extractor->get_warnings());
                    $sourcesummary[] = [
                        'filename' => $source['filename'],
                        'type' => 'image',
                        'pages' => 1,
                        'pagefile' => $sourcefile,
                        'pagenumber' => $page,
                    ];
                    $additems($items, $prepared, $sourcefile);
                    unset($prepared);
                } catch (\moodle_exception $e) {
                    $warnings[] = get_string('import_warn_filefailed', 'local_ai_yared_course', (object) [
                        'file' => s($source['filename']),
                        'error' => $e->getMessage(),
                    ]);
                    continue;
                }
            }

            if ($limited) {
                $warnings[] = get_string('import_warn_total', 'local_ai_yared_course', exercise_extractor::MAX_PER_PDF);
            }
            if ($duplicates > 0) {
                $warnings[] = get_string('import_warn_duplicates', 'local_ai_yared_course', $duplicates);
            }
            if ($noimage > 0) {
                $warnings[] = get_string('import_warn_noimage', 'local_ai_yared_course', $noimage);
            }
            if (!$exercises) {
                throw new \moodle_exception('import_error_noexercises', 'local_ai_yared_course');
            }

            $manifest = [
                'version' => 1,
                'userid' => $USER->id,
                'courseid' => $course->id,
                'timecreated' => time(),
                'categoryid' => $categoryid,
                'newcategory' => $newcategory,
                'language' => $formdata->language,
                'level' => $formdata->level,
                'age' => $age,
                'math' => true,
                'attachimage' => $attachimage,
                'sources' => $sourcesummary,
                'exercises' => $exercises,
                'warnings' => array_values(array_unique($warnings)),
            ];
            import_store::save_manifest($draftid, $USER->id, $manifest);
            $fallbacks = $client->get_fallback_messages();
            if ($fallbacks) {
                $warnings[] = get_string('warn_fallback', 'local_ai_yared_course', s(implode(' | ', $fallbacks)));
            }
            redirect(new moodle_url('/local/ai_yared_course/import.php', [
                'id' => $course->id,
                'draft' => $draftid,
            ]));
        } catch (\moodle_exception $e) {
            if ($draftid !== null) {
                import_store::delete($draftid, $USER->id);
            }
            $errors[] = $e->getMessage();
            $mform->set_data($formdata);
        }
    }
}

// Save the reviewed questions.
if ($action === 'save') {
    require_sesskey();
    $draftid = required_param('draft', PARAM_INT);
    $posted = $_POST['items'] ?? null;
    try {
        $manifest = import_store::load($draftid, $USER->id, $course->id);
    } catch (\moodle_exception $e) {
        $errors[] = $e->getMessage();
    }

    if ($manifest !== null) {
        $showform = false;
        $questions = [];
        $scalar = function ($value): string {
            return is_scalar($value) ? (string) $value : '';
        };
        foreach ($manifest['exercises'] as $i => $ex) {
            $input = is_array($posted) && isset($posted[$i]) && is_array($posted[$i]) ? $posted[$i] : null;
            if (!$input || empty($input['include'])) {
                continue;
            }
            $label = $ex['number'] !== '' ? $ex['number'] : (string) ($i + 1);
            $text = trim(clean_param($scalar($input['text'] ?? ''), PARAM_RAW));
            if ($text === '') {
                $errors[] = get_string('import_err_text', 'local_ai_yared_course', s($label));
                continue;
            }
            if (\core_text::strlen($text) > 5000) {
                $text = \core_text::substr($text, 0, 5000);
            }
            $feedback = trim(clean_param($scalar($input['feedback'] ?? ''), PARAM_RAW));
            if (\core_text::strlen($feedback) > 4000) {
                $feedback = \core_text::substr($feedback, 0, 4000);
            }

            $question = [
                'type' => $ex['type'],
                'text' => $text,
                'feedback' => $feedback,
                'image' => null,
                'imagealt' => '',
                'math' => true,
            ];

            if ($ex['type'] === 'truefalse') {
                $answer = $scalar($input['answer'] ?? '');
                if (!in_array($answer, ['0', '1'], true)) {
                    $errors[] = get_string('import_err_answer', 'local_ai_yared_course', s($label));
                    continue;
                }
                $question['answer'] = $answer === '1';
                $question['options'] = [];
            } else {
                $options = [];
                $correct = isset($input['correct']) ? (int) $input['correct'] : -1;
                $iscorrectvalid = true;
                foreach ($ex['options'] as $j => $option) {
                    $optiontext = '';
                    if (is_array($input['options'] ?? null) && isset($input['options'][$j]['text'])) {
                        $optiontext = trim(clean_param($scalar($input['options'][$j]['text']), PARAM_RAW));
                    }
                    if (\core_text::strlen($optiontext) > 1000) {
                        $optiontext = \core_text::substr($optiontext, 0, 1000);
                    }
                    if ($optiontext === '') {
                        if ($correct === (int) $j) {
                            $iscorrectvalid = false;
                        }
                        continue;
                    }
                    $options[] = ['text' => $optiontext, 'correct' => $correct === (int) $j];
                }
                if (count($options) < 2) {
                    $errors[] = get_string('import_err_options', 'local_ai_yared_course', s($label));
                    continue;
                }
                $correctcount = 0;
                foreach ($options as $option) {
                    $correctcount += $option['correct'] ? 1 : 0;
                }
                if ($correctcount !== 1 || !$iscorrectvalid) {
                    $errors[] = get_string('import_err_correct', 'local_ai_yared_course', s($label));
                    continue;
                }
                $question['options'] = $options;
            }

            if (!empty($input['useimage'])) {
                $imagedata = null;
                $rawbox = $scalar($input['box'] ?? '');
                $box = null;
                if ($rawbox !== '') {
                    $decodedbox = json_decode($rawbox, true);
                    $box = crop_helper::normalise_box($decodedbox);
                }
                if ($box !== null && !empty($ex['sourcefile'])) {
                    $sourcedata = import_store::read_file($draftid, $USER->id, $ex['sourcefile']);
                    if ($sourcedata !== null) {
                        $crop = crop_helper::crop($sourcedata, $box);
                        if ($crop !== null) {
                            $imagedata = $crop['data'];
                        } else {
                            $warnings[] = get_string('import_warn_cropfailed', 'local_ai_yared_course', s($label));
                        }
                    }
                }
                // Keep the stored crop when the teacher did not change the box or the new crop failed.
                if ($imagedata === null && !empty($ex['image'])) {
                    $imagedata = import_store::read_file($draftid, $USER->id, $ex['image']);
                }
                if ($imagedata !== null) {
                    $info = @getimagesizefromstring($imagedata);
                    $mimetype = $info ? image_type_to_mime_type($info[2]) : 'image/png';
                    $question['image'] = 'data:' . $mimetype . ';base64,' . base64_encode($imagedata);
                    $alt = trim(clean_param($scalar($input['imagealt'] ?? ''), PARAM_TEXT));
                    $question['imagealt'] = \core_text::substr($alt, 0, 250);
                }
            }

            $questions[] = $question;
        }

        if (!$errors && !$questions) {
            $errors[] = get_string('import_err_none', 'local_ai_yared_course');
        }

        if (!$errors) {
            try {
                if ((int) $manifest['categoryid'] === 0) {
                    require_capability('moodle/question:managecategory', $context);
                    $category = category_helper::create($context, (string) $manifest['newcategory']);
                } else {
                    $category = $DB->get_record('question_categories', [
                        'id' => (int) $manifest['categoryid'],
                        'contextid' => $context->id,
                    ], '*', MUST_EXIST);
                }

                $result = question_saver::save($questions, $category, !empty($_POST['draftstatus']));
                if ($result['created'] === 0) {
                    throw new \moodle_exception('import_error_save', 'local_ai_yared_course');
                }
                import_store::delete($draftid, $USER->id);
                $message = get_string('import_saved', 'local_ai_yared_course', (object) [
                    'created' => $result['created'],
                    'category' => format_string($category->name, true, ['context' => $context]),
                ]);
                if ($result['failed'] > 0) {
                    $message .= ' ' . get_string('failed', 'local_ai_yared_course', $result['failed']);
                }
                $target = new moodle_url('/question/edit.php', [
                    'courseid' => $course->id,
                    'cat' => $category->id . ',' . $category->contextid,
                ]);
                redirect($target, $message, null, $result['failed'] > 0
                    ? \core\output\notification::NOTIFY_WARNING
                    : \core\output\notification::NOTIFY_SUCCESS);
            } catch (\moodle_exception $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
}

// Review a pending import.
if ($action === '' && !$manifest) {
    $draftid = optional_param('draft', 0, PARAM_INT);
    if ($draftid) {
        try {
            $manifest = import_store::load($draftid, $USER->id, $course->id);
            $showform = false;
            $reviewdraft = $draftid;
        } catch (\moodle_exception $e) {
            $errors[] = $e->getMessage();
        }
    } else {
        import_store::cleanup_old($USER->id);
    }
} else if ($action === 'save' && $manifest) {
    // Validation errors: keep the review visible with the teacher's edits.
    $showform = false;
    $reviewdraft = (int) ($_POST['draft'] ?? 0);
}

$mform = $mform ?? new import_form($PAGE->url->out(false), [
    'courseid' => $course->id,
    'categories' => $categories,
    'cancreatecategory' => $cancreatecategory,
]);

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('import_heading', 'local_ai_yared_course'));

foreach ($errors as $error) {
    echo $OUTPUT->notification($error, 'error');
}
foreach ($warnings as $warning) {
    echo $OUTPUT->notification($warning, 'warning');
}

if ($manifest && !$showform) {
    local_ai_yared_course_render_review($manifest, $reviewdraft, $posted, $context);
    echo $OUTPUT->footer();
    exit;
}

echo html_writer::tag('p', get_string('import_intro', 'local_ai_yared_course'), ['class' => 'text-muted']);
if (!$client->supports_pdf()) {
    echo $OUTPUT->notification(get_string('import_nopdfwarning', 'local_ai_yared_course'), 'info');
}
echo html_writer::div(
    $OUTPUT->single_button($bankurl, get_string('import_backtobank', 'local_ai_yared_course'), 'get'),
    'mb-3'
);

echo html_writer::start_div('aiyared-import-steps');
foreach ([1, 2, 3] as $step) {
    echo html_writer::div(
        html_writer::span((string) $step, 'aiyared-import-step-number') .
        html_writer::span(get_string('import_step' . $step, 'local_ai_yared_course')),
        'aiyared-import-step'
    );
}
echo html_writer::end_div();

$mform->display();

$messages = [
    get_string('import_wait_prepare', 'local_ai_yared_course'),
    get_string('import_wait_reading', 'local_ai_yared_course'),
    get_string('import_wait_splitting', 'local_ai_yared_course'),
    get_string('import_wait_cropping', 'local_ai_yared_course'),
    get_string('import_wait_review', 'local_ai_yared_course'),
];
local_ai_yared_course_render_wait($messages, get_string('import_wait_title', 'local_ai_yared_course'),
    get_string('import_wait_intro', 'local_ai_yared_course'));

echo $OUTPUT->footer();

/**
 * Render the waiting overlay and its rotation script.
 *
 * @param string[] $messages Messages shown in order.
 * @param string $title Overlay title.
 * @param string $intro Overlay introduction.
 */
function local_ai_yared_course_render_wait(array $messages, string $title, string $intro): void {
    global $PAGE;

    echo html_writer::start_div('yared-bank-wait', [
        'id' => 'yared-bank-wait',
        'hidden' => 'hidden',
        'role' => 'dialog',
        'aria-modal' => 'true',
        'aria-labelledby' => 'yared-bank-wait-title',
        'aria-describedby' => 'yared-bank-wait-intro',
        'aria-hidden' => 'true',
        'tabindex' => '-1',
    ]);
    echo html_writer::start_div('yared-bank-wait-card');
    echo html_writer::div('', 'yared-bank-wait-spinner', ['aria-hidden' => 'true']);
    echo html_writer::tag('h2', $title, ['id' => 'yared-bank-wait-title', 'class' => 'h4 mb-2']);
    echo html_writer::tag('p', $intro, ['id' => 'yared-bank-wait-intro', 'class' => 'text-muted']);
    echo html_writer::tag('p', '', [
        'id' => 'yared-bank-wait-message',
        'class' => 'yared-bank-wait-message',
        'aria-live' => 'polite',
    ]);
    echo html_writer::div(
        html_writer::span(get_string('bank_generating_elapsed', 'local_ai_yared_course'),
            'yared-bank-wait-elapsed-label') . ' ' .
        html_writer::tag('strong', '00:00', ['id' => 'yared-bank-wait-time']),
        'yared-bank-wait-elapsed'
    );
    echo html_writer::end_div();
    echo html_writer::end_div();

    $json = json_encode($messages, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $js = <<<JS
(function() {
    'use strict';

    function init() {
        var button = document.getElementById('id_submitbutton');
        var form = button ? button.closest('form') : document.querySelector('form.mform');
        if (!button && form) {
            button = form.querySelector('button[type="submit"], input[type="submit"]');
        }
        var overlay = document.getElementById('yared-bank-wait');
        if (!form || !button || !overlay) {
            return;
        }
        var message = document.getElementById('yared-bank-wait-message');
        var time = document.getElementById('yared-bank-wait-time');
        var messages = {$json};
        var started = 0;
        var tick = null;
        var rotate = null;
        var index = 0;
        var submitting = false;

        function pad(value) {
            return (value < 10 ? '0' : '') + value;
        }
        function updateTime() {
            if (!started || !time) { return; }
            var elapsed = Math.max(0, Math.floor((Date.now() - started) / 1000));
            var hours = Math.floor(elapsed / 3600);
            var minutes = Math.floor((elapsed % 3600) / 60);
            var seconds = elapsed % 60;
            time.textContent = (hours > 0 ? hours + ':' : '') + pad(minutes) + ':' + pad(seconds);
        }
        function hide() {
            submitting = false;
            overlay.hidden = true;
            overlay.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('yared-bank-waiting');
            if (tick) { window.clearInterval(tick); tick = null; }
            if (rotate) { window.clearInterval(rotate); rotate = null; }
            button.removeAttribute('aria-disabled');
        }
        function show() {
            if (submitting) { return; }
            submitting = true;
            index = 0;
            overlay.hidden = false;
            overlay.setAttribute('aria-hidden', 'false');
            document.body.classList.add('yared-bank-waiting');
            if (message) { message.textContent = messages[0]; }
            started = Date.now();
            updateTime();
            tick = window.setInterval(updateTime, 1000);
            rotate = window.setInterval(function() {
                index = (index + 1) % messages.length;
                if (message) { message.textContent = messages[index]; }
            }, 5000);
            button.setAttribute('aria-disabled', 'true');
            try { overlay.focus(); } catch (e) { /* Ignore. */ }
        }

        form.addEventListener('submit', function(event) {
            if (submitting) { event.preventDefault(); return; }
            if (typeof form.checkValidity === 'function' && !form.checkValidity()) { return; }
            show();
        });
        form.addEventListener('invalid', hide, true);
        window.addEventListener('pageshow', function(event) {
            if (event.persisted) { hide(); }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
JS;
    $PAGE->requires->js_init_code($js);
}

/**
 * Render the review page with one editable card per detected exercise.
 *
 * @param array $manifest Stored manifest.
 * @param int $draftid Draft id.
 * @param array|null $posted Submitted values, when the save had validation errors.
 * @param \context $context Course context.
 */
function local_ai_yared_course_render_review(array $manifest, int $draftid, ?array $posted, $context): void {
    global $OUTPUT, $PAGE, $DB, $USER;

    $count = count($manifest['exercises']);
    $categoryname = '';
    if ((int) $manifest['categoryid'] > 0) {
        $categoryname = (string) $DB->get_field('question_categories', 'name',
            ['id' => (int) $manifest['categoryid']], IGNORE_MISSING);
        $categoryname = format_string($categoryname, true, ['context' => $context]);
    } else {
        $categoryname = format_string((string) $manifest['newcategory'], true, ['context' => $context]);
    }

    echo html_writer::div(
        html_writer::tag('strong', get_string('import_review_title', 'local_ai_yared_course',
            (object) ['count' => $count])) . ' ' .
        html_writer::tag('span', get_string('import_review_category', 'local_ai_yared_course',
            (object) ['category' => $categoryname]), ['class' => 'text-muted']),
        'alert alert-info'
    );

    foreach ($manifest['warnings'] ?? [] as $warning) {
        echo $OUTPUT->notification($warning, 'warning');
    }

    // Makes Moodle load the LaTeX filter on this page, so the previews loaded later can be typeset.
    echo html_writer::div(format_text('\\(x\\)', FORMAT_HTML, ['context' => $context]), 'd-none');

    $formurl = new moodle_url('/local/ai_yared_course/import.php');
    echo html_writer::start_tag('form', [
        'method' => 'post',
        'action' => $formurl->out(false),
        'class' => 'aiyared-import-form',
        'id' => 'aiyared-import-form',
    ]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $manifest['courseid']]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'draft', 'value' => $draftid]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'save']);

    $sources = [];
    foreach ($manifest['sources'] as $source) {
        $sources[] = s($source['filename']);
    }
    echo html_writer::tag('p', get_string('import_review_sources', 'local_ai_yared_course',
        (object) ['files' => implode(', ', $sources)]), ['class' => 'text-muted small']);

    echo html_writer::start_div('aiyared-import-toolbar d-flex flex-wrap gap-3 align-items-center mb-3');
    echo html_writer::tag('label',
        html_writer::empty_tag('input', ['type' => 'checkbox', 'id' => 'aiyared-selectall', 'checked' => 'checked',
            'class' => 'form-check-input me-1']) . get_string('import_selectall', 'local_ai_yared_course'),
        ['class' => 'form-check-label']);
    echo html_writer::tag('label',
        html_writer::empty_tag('input', ['type' => 'checkbox', 'name' => 'draftstatus', 'value' => '1',
            'class' => 'form-check-input me-1']) . get_string('import_draftstatus', 'local_ai_yared_course'),
        ['class' => 'form-check-label']);
    echo html_writer::end_div();

    foreach ($manifest['exercises'] as $i => $ex) {
        $value = is_array($posted) && isset($posted[$i]) && is_array($posted[$i]) ? $posted[$i] : null;
        $label = $ex['number'] !== '' ? $ex['number'] : (string) ($i + 1);
        $included = $value !== null ? !empty($value['include']) : true;
        $text = $value !== null ? (string) ($value['text'] ?? '') : $ex['text'];
        $feedback = $value !== null ? (string) ($value['feedback'] ?? '') : $ex['feedback'];
        $useimage = $value !== null ? !empty($value['useimage']) : !empty($ex['useimage']);
        $imagealt = $value !== null ? (string) ($value['imagealt'] ?? '') : (string) $ex['imagealt'];
        $hasimage = !empty($ex['image']);
        $imageurl = $hasimage ? \local_ai_yared_course\local\import_store::file_url($draftid, $USER->id,
            $ex['image'])->out(false) : '';
        $sourcefile = (string) ($ex['sourcefile'] ?? '');
        $sourceurl = $sourcefile !== '' ? \local_ai_yared_course\local\import_store::file_url($draftid, $USER->id,
            $sourcefile)->out(false) : '';
        $currentbox = $ex['box'] ?? $ex['figure'] ?? $ex['exercise'] ?? null;
        if ($value !== null && array_key_exists('box', $value)) {
            $postedbox = crop_helper::normalise_box(json_decode((string) $value['box'], true));
            if ($postedbox !== null) {
                $currentbox = $postedbox;
            }
        }
        $boxjson = $currentbox ? json_encode($currentbox, JSON_UNESCAPED_SLASHES) : '';
        $figurejson = !empty($ex['figure']) ? json_encode($ex['figure'], JSON_UNESCAPED_SLASHES) : '';
        $exercisejson = !empty($ex['exercise']) ? json_encode($ex['exercise'], JSON_UNESCAPED_SLASHES) : '';

        echo html_writer::start_div('aiyared-import-card card mb-3');
        echo html_writer::start_div('card-body');

        $badges = html_writer::span(get_string('import_exercise', 'local_ai_yared_course', s($label)),
            'badge text-bg-primary me-1');
        $badges .= html_writer::span($ex['type'] === 'truefalse'
            ? get_string('qtype_truefalse', 'local_ai_yared_course')
            : get_string('qtype_multichoice', 'local_ai_yared_course'),
            'badge text-bg-secondary me-1');
        if (!empty($ex['page'])) {
            $badges .= html_writer::span(get_string('import_page', 'local_ai_yared_course', (int) $ex['page']),
                'badge text-bg-light me-1');
        }
        if (!empty($ex['needsreview'])) {
            $badges .= html_writer::span(get_string('import_needsreview', 'local_ai_yared_course'),
                'badge text-bg-warning me-1');
        }
        if (!empty($ex['needsfigure'])) {
            $badges .= html_writer::span(get_string('import_needsfigure', 'local_ai_yared_course'),
                'badge text-bg-warning me-1');
        }

        echo html_writer::start_div('d-flex justify-content-between align-items-start mb-2');
        echo html_writer::tag('div', $badges, ['class' => 'aiyared-import-badges']);
        echo html_writer::tag('label',
            html_writer::empty_tag('input', [
                'type' => 'checkbox',
                'name' => 'items[' . $i . '][include]',
                'value' => '1',
                'class' => 'form-check-input me-1 aiyared-import-include',
                'checked' => $included ? 'checked' : null,
            ]) . get_string('import_include', 'local_ai_yared_course'),
            ['class' => 'form-check-label text-nowrap']);
        echo html_writer::end_div();

        echo html_writer::start_div('row g-3');
        echo html_writer::start_div('col-lg-7');

        $textid = 'aiyared-text-' . $i;
        echo html_writer::tag('label', get_string('import_statement', 'local_ai_yared_course'),
            ['for' => $textid, 'class' => 'form-label fw-bold']);
        echo html_writer::tag('textarea', s($text), [
            'name' => 'items[' . $i . '][text]',
            'id' => $textid,
            'class' => 'form-control mb-2',
            'rows' => 4,
        ]);

        if ($ex['type'] === 'truefalse') {
            $answer = $value !== null ? (string) ($value['answer'] ?? '') : ($ex['answer'] ? '1' : '0');
            echo html_writer::tag('div',
                html_writer::tag('label',
                    html_writer::empty_tag('input', [
                        'type' => 'radio',
                        'name' => 'items[' . $i . '][answer]',
                        'value' => '1',
                        'class' => 'form-check-input me-1',
                        'checked' => $answer === '1' ? 'checked' : null,
                    ]) . get_string('true', 'qtype_truefalse'),
                    ['class' => 'form-check-label me-3']) .
                html_writer::tag('label',
                    html_writer::empty_tag('input', [
                        'type' => 'radio',
                        'name' => 'items[' . $i . '][answer]',
                        'value' => '0',
                        'class' => 'form-check-input me-1',
                        'checked' => $answer === '0' ? 'checked' : null,
                    ]) . get_string('false', 'qtype_truefalse'),
                    ['class' => 'form-check-label']),
                ['class' => 'mb-2']);
        } else {
            $postedoptions = $value !== null && is_array($value['options'] ?? null) ? $value['options'] : [];
            $correct = $value !== null ? (int) ($value['correct'] ?? -1) : -1;
            $table = new html_table();
            $table->attributes['class'] = 'table table-sm align-middle aiyared-import-options mb-2';
            $table->head = [
                get_string('import_correct', 'local_ai_yared_course'),
                get_string('import_option', 'local_ai_yared_course'),
            ];
            foreach ($ex['options'] as $j => $option) {
                $otext = $postedoptions ? (string) ($postedoptions[$j]['text'] ?? '') : $option['text'];
                $ischecked = $value !== null ? ($correct === (int) $j) : !empty($option['correct']);
                $radio = html_writer::empty_tag('input', [
                    'type' => 'radio',
                    'name' => 'items[' . $i . '][correct]',
                    'value' => $j,
                    'class' => 'form-check-input',
                    'checked' => $ischecked ? 'checked' : null,
                    'aria-label' => get_string('import_correct', 'local_ai_yared_course') . ' ' . ($j + 1),
                ]);
                $input = html_writer::empty_tag('input', [
                    'type' => 'text',
                    'name' => 'items[' . $i . '][options][' . $j . '][text]',
                    'value' => $otext,
                    'class' => 'form-control form-control-sm',
                ]);
                $table->data[] = [html_writer::div($radio, 'form-check'), $input];
            }
            echo html_writer::table($table);
        }

        $feedbackid = 'aiyared-feedback-' . $i;
        echo html_writer::tag('label', get_string('import_feedback', 'local_ai_yared_course'),
            ['for' => $feedbackid, 'class' => 'form-label fw-bold']);
        echo html_writer::tag('textarea', s($feedback), [
            'name' => 'items[' . $i . '][feedback]',
            'id' => $feedbackid,
            'class' => 'form-control',
            'rows' => 2,
        ]);
        echo html_writer::tag('button', get_string('import_preview', 'local_ai_yared_course'), [
            'type' => 'button',
            'class' => 'btn btn-sm btn-outline-primary mt-2 aiyared-preview-btn',
            'data-index' => $i,
            'data-type' => $ex['type'],
        ]);
        echo html_writer::div('', 'aiyared-preview-panel border rounded p-3 mt-2', [
            'id' => 'aiyared-preview-' . $i,
            'hidden' => 'hidden',
            'aria-live' => 'polite',
        ]);

        echo html_writer::end_div(); // Column.

        echo html_writer::start_div('col-lg-5');
        $canadjust = $sourceurl !== '';
        if ($hasimage || $canadjust) {
            echo html_writer::start_div('aiyared-import-image' . ($useimage || !$hasimage ? '' : ' opacity-50'));
            echo html_writer::empty_tag('img', [
                'src' => $hasimage ? $imageurl : null,
                'alt' => s($imagealt),
                'class' => 'img-fluid rounded border mb-2' . ($hasimage ? '' : ' d-none'),
                'loading' => 'lazy',
                'id' => 'aiyared-image-' . $i,
                'data-original-src' => $hasimage ? $imageurl : '',
            ]);
            if (!$hasimage) {
                echo html_writer::tag('p', get_string('import_noimage', 'local_ai_yared_course'),
                    ['class' => 'text-muted small aiyared-noimage', 'id' => 'aiyared-noimage-' . $i]);
            }
            echo html_writer::end_div();
            if ($hasimage) {
                echo html_writer::tag('label',
                    html_writer::empty_tag('input', [
                        'type' => 'checkbox',
                        'name' => 'items[' . $i . '][useimage]',
                        'value' => '1',
                        'class' => 'form-check-input me-1 aiyared-import-useimage',
                        'checked' => $useimage ? 'checked' : null,
                        'data-index' => $i,
                    ]) . get_string('import_useimage', 'local_ai_yared_course'),
                    ['class' => 'form-check-label d-block mb-2']);
            } else if ($canadjust) {
                echo html_writer::tag('label',
                    html_writer::empty_tag('input', [
                        'type' => 'checkbox',
                        'name' => 'items[' . $i . '][useimage]',
                        'value' => '1',
                        'class' => 'form-check-input me-1 aiyared-import-useimage',
                        'checked' => $useimage ? 'checked' : null,
                        'data-index' => $i,
                    ]) . get_string('import_usecrop', 'local_ai_yared_course'),
                    ['class' => 'form-check-label d-block mb-2']);
            }
            if ($canadjust) {
                echo html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'items[' . $i . '][box]',
                    'value' => $boxjson,
                    'id' => 'aiyared-box-' . $i,
                    'class' => 'aiyared-import-box',
                ]);
                echo html_writer::tag('button',
                    html_writer::tag('i', '', ['class' => 'fa fa-crop me-1', 'aria-hidden' => 'true']) .
                    get_string($hasimage ? 'import_adjustcrop' : 'import_makecrop', 'local_ai_yared_course'),
                    [
                        'type' => 'button',
                        'class' => 'btn btn-sm btn-outline-primary aiyared-adjustcrop mb-2',
                        'data-index' => $i,
                        'data-source' => $sourceurl,
                        'data-box' => $boxjson,
                        'data-figure' => $figurejson,
                        'data-exercise' => $exercisejson,
                        'data-preview' => 'aiyared-image-' . $i,
                        'data-label' => s($label),
                        'aria-label' => get_string('import_adjustcrop_aria', 'local_ai_yared_course', s($label)),
                    ]);
                echo html_writer::tag('p', get_string('import_adjustcrop_help', 'local_ai_yared_course'),
                    ['class' => 'text-muted small mb-2']);
            }
            echo html_writer::empty_tag('input', [
                'type' => 'text',
                'name' => 'items[' . $i . '][imagealt]',
                'value' => $imagealt,
                'class' => 'form-control form-control-sm',
                'placeholder' => get_string('import_imagealt', 'local_ai_yared_course'),
                'aria-label' => get_string('import_imagealt', 'local_ai_yared_course'),
            ]);
        } else {
            // Explain it once; repeating the long text under every question only adds noise.
            static $explainednoimage = false;
            echo html_writer::tag('p', get_string($explainednoimage ? 'import_noimage_pdf_short'
                : 'import_noimage_pdf', 'local_ai_yared_course'), ['class' => 'text-muted small']);
            $explainednoimage = true;
        }
        echo html_writer::end_div(); // Column.

        echo html_writer::end_div(); // Row.
        echo html_writer::end_div(); // Card body.
        echo html_writer::end_div(); // Card.
    }

    echo html_writer::start_div('d-flex flex-wrap gap-2 mb-4');
    echo html_writer::tag('button', get_string('import_save', 'local_ai_yared_course'), [
        'type' => 'submit',
        'class' => 'btn btn-primary',
        'id' => 'aiyared-import-save',
    ]);
    $discard = new moodle_url('/local/ai_yared_course/import.php', [
        'id' => $manifest['courseid'],
        'draft' => $draftid,
        'action' => 'discard',
        'sesskey' => sesskey(),
    ]);
    echo html_writer::link($discard, get_string('import_discard', 'local_ai_yared_course'),
        ['class' => 'btn btn-outline-secondary', 'data-aiyared-confirm' => '1']);
    echo html_writer::end_div();
    echo html_writer::end_tag('form');

    // Crop editor: the teacher draws the exact region of the page that will accompany the question.
    echo html_writer::start_tag('dialog', [
        'id' => 'aiyared-crop-dialog',
        'class' => 'aiyared-crop-dialog',
        'aria-labelledby' => 'aiyared-crop-title',
    ]);
    echo html_writer::start_div('aiyared-crop-card');
    echo html_writer::start_div('d-flex justify-content-between align-items-start gap-2 mb-2');
    echo html_writer::tag('h2', get_string('import_crop_title', 'local_ai_yared_course'),
        ['id' => 'aiyared-crop-title', 'class' => 'h4 mb-0']);
    echo html_writer::tag('button', '&times;', [
        'type' => 'button',
        'class' => 'btn-close',
        'id' => 'aiyared-crop-close',
        'aria-label' => get_string('import_crop_close', 'local_ai_yared_course'),
    ]);
    echo html_writer::end_div();
    echo html_writer::tag('p', get_string('import_crop_intro', 'local_ai_yared_course'),
        ['class' => 'text-muted']);
    echo html_writer::tag('p', '', [
        'id' => 'aiyared-crop-label',
        'class' => 'fw-bold small mb-2',
    ]);
    echo html_writer::start_div('aiyared-crop-stage', ['id' => 'aiyared-crop-stage']);
    echo html_writer::empty_tag('img', [
        'id' => 'aiyared-crop-image',
        'class' => 'aiyared-crop-image',
        'alt' => get_string('import_crop_imagealt', 'local_ai_yared_course'),
    ]);
    echo html_writer::start_div('aiyared-crop-selection', ['id' => 'aiyared-crop-selection', 'hidden' => 'hidden']);
    echo html_writer::tag('span', '', ['class' => 'aiyared-crop-handle aiyared-crop-handle-se',
        'data-handle' => 'se']);
    echo html_writer::end_div();
    echo html_writer::end_div();
    echo html_writer::tag('p', get_string('import_crop_hint', 'local_ai_yared_course'),
        ['class' => 'text-muted small mt-2']);
    echo html_writer::start_div('d-flex flex-wrap gap-2 align-items-center');
    echo html_writer::tag('button', get_string('import_crop_figure', 'local_ai_yared_course'), [
        'type' => 'button',
        'class' => 'btn btn-sm btn-outline-secondary',
        'id' => 'aiyared-crop-figure',
        'hidden' => 'hidden',
    ]);
    echo html_writer::tag('button', get_string('import_crop_exercise', 'local_ai_yared_course'), [
        'type' => 'button',
        'class' => 'btn btn-sm btn-outline-secondary',
        'id' => 'aiyared-crop-exercise',
        'hidden' => 'hidden',
    ]);
    echo html_writer::tag('span', '', ['class' => 'flex-grow-1']);
    echo html_writer::tag('button', get_string('cancel'), [
        'type' => 'button',
        'class' => 'btn btn-outline-secondary',
        'id' => 'aiyared-crop-cancel',
    ]);
    echo html_writer::tag('button', get_string('import_crop_apply', 'local_ai_yared_course'), [
        'type' => 'button',
        'class' => 'btn btn-primary',
        'id' => 'aiyared-crop-apply',
    ]);
    echo html_writer::end_div();
    echo html_writer::end_div();
    echo html_writer::end_tag('dialog');

    $noselection = json_encode(get_string('import_err_noselection', 'local_ai_yared_course'),
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $saving = json_encode(get_string('import_saving', 'local_ai_yared_course'),
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $confirm = json_encode(get_string('import_discardconfirm', 'local_ai_yared_course'),
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $croprequired = json_encode(get_string('import_crop_required', 'local_ai_yared_course'),
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $croplabel = json_encode(get_string('import_crop_label', 'local_ai_yared_course', '__LABEL__'),
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $previewlabels = json_encode([
        'show' => get_string('import_preview', 'local_ai_yared_course'),
        'hide' => get_string('import_preview_hide', 'local_ai_yared_course'),
        'loading' => get_string('import_preview_loading', 'local_ai_yared_course'),
        'error' => get_string('import_preview_error', 'local_ai_yared_course'),
        'statement' => get_string('import_preview_statement', 'local_ai_yared_course'),
        'options' => get_string('import_preview_options', 'local_ai_yared_course'),
        'feedback' => get_string('import_preview_feedback', 'local_ai_yared_course'),
        'correct' => get_string('import_preview_correct', 'local_ai_yared_course'),
        'answer' => get_string('import_preview_answer', 'local_ai_yared_course'),
        'nomath' => get_string('import_preview_nomath', 'local_ai_yared_course'),
        'noanswer' => get_string('import_preview_noanswer', 'local_ai_yared_course'),
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
    $js = <<<JS
(function() {
    'use strict';
    function init() {
        var form = document.getElementById('aiyared-import-form');
        if (!form) { return; }

        // Preview of each question: statement, image, options and feedback, as Moodle will show them.
        var PL = {$previewlabels};
        function heading(text) {
            var h = document.createElement('div');
            h.className = 'fw-bold small text-uppercase text-muted mt-2';
            h.textContent = text;
            return h;
        }
        function box(html) {
            var d = document.createElement('div');
            d.innerHTML = html;
            return d;
        }
        function typeset(node) {
            try {
                require(['jquery', 'core_filters/events'], function($, events) {
                    events.notifyFilterContentUpdated($(node));
                }, function() { /* The LaTeX filter is not available: the text stays as written. */ });
            } catch (e) { /* Ignore. */ }
        }
        function renderPreview(panel, index, data) {
            panel.textContent = '';
            panel.appendChild(heading(PL.statement));
            panel.appendChild(box(data.text));
            var useimage = form.querySelector('input[name="items[' + index + '][useimage]"]');
            var image = document.getElementById('aiyared-image-' + index);
            if (image && image.getAttribute('src') && !image.classList.contains('d-none')
                    && (!useimage || useimage.checked)) {
                var copy = document.createElement('img');
                copy.src = image.getAttribute('src');
                copy.className = 'img-fluid rounded border my-2';
                copy.alt = image.alt || '';
                panel.appendChild(copy);
            }
            if (data.options && data.options.length) {
                panel.appendChild(heading(PL.options));
                var list = document.createElement('div');
                data.options.forEach(function(option, position) {
                    var row = document.createElement('div');
                    row.className = 'd-flex align-items-baseline gap-2 py-1' + (option.correct ? ' text-success fw-bold' : '');
                    var letter = document.createElement('span');
                    letter.textContent = String.fromCharCode(65 + position) + ')';
                    row.appendChild(letter);
                    var body = box(option.html);
                    body.className = 'flex-grow-1';
                    row.appendChild(body);
                    if (option.correct) {
                        var mark = document.createElement('span');
                        mark.className = 'badge text-bg-success';
                        mark.textContent = PL.correct;
                        row.appendChild(mark);
                    }
                    list.appendChild(row);
                });
                panel.appendChild(list);
                if (!data.options.some(function(option) { return option.correct; })) {
                    var warning = document.createElement('div');
                    warning.className = 'text-warning small';
                    warning.textContent = PL.noanswer;
                    panel.appendChild(warning);
                }
            } else if (data.answer) {
                panel.appendChild(heading(PL.answer));
                var answer = document.createElement('div');
                answer.className = 'text-success fw-bold';
                answer.textContent = data.answer;
                panel.appendChild(answer);
            }
            if (data.feedback) {
                panel.appendChild(heading(PL.feedback));
                panel.appendChild(box(data.feedback));
            }
            if (!data.mathactive) {
                var note = document.createElement('div');
                note.className = 'text-muted small mt-2';
                note.textContent = PL.nomath;
                panel.appendChild(note);
            }
            typeset(panel);
        }
        function togglePreview(button) {
            var index = button.getAttribute('data-index');
            var panel = document.getElementById('aiyared-preview-' + index);
            if (!panel) { return; }
            if (!panel.hidden) {
                panel.hidden = true;
                button.textContent = PL.show;
                return;
            }
            var field = function(name) { return form.querySelector('[name="items[' + index + '][' + name + ']"]'); };
            var body = new URLSearchParams();
            body.append('sesskey', form.querySelector('input[name="sesskey"]').value);
            body.append('id', form.querySelector('input[name="id"]').value);
            body.append('action', 'preview');
            body.append('type', button.getAttribute('data-type'));
            body.append('text', field('text') ? field('text').value : '');
            body.append('feedback', field('feedback') ? field('feedback').value : '');
            var answer = form.querySelector('input[name="items[' + index + '][answer]"]:checked');
            if (answer) { body.append('answer', answer.value); }
            var correct = form.querySelector('input[name="items[' + index + '][correct]"]:checked');
            if (correct) { body.append('correct', correct.value); }
            form.querySelectorAll('input[name^="items[' + index + '][options]"]').forEach(function(input) {
                var match = input.name.match(/\[options\]\[(\d+)\]\[text\]$/);
                if (match) { body.append('options[' + match[1] + ']', input.value); }
            });
            panel.textContent = PL.loading;
            panel.hidden = false;
            button.textContent = PL.hide;
            fetch(form.getAttribute('action'), {method: 'POST', body: body, credentials: 'same-origin'})
                .then(function(response) {
                    if (!response.ok) { throw new Error('http'); }
                    return response.json();
                })
                .then(function(data) { renderPreview(panel, index, data); })
                .catch(function() { panel.textContent = PL.error; });
        }
        form.querySelectorAll('.aiyared-preview-btn').forEach(function(button) {
            button.addEventListener('click', function() { togglePreview(button); });
        });
        var all = document.getElementById('aiyared-selectall');
        if (all) {
            all.addEventListener('change', function() {
                form.querySelectorAll('input[name$="[include]"]').forEach(function(box) {
                    box.checked = all.checked;
                });
            });
        }
        form.querySelectorAll('.aiyared-import-useimage').forEach(function(box) {
            box.addEventListener('change', function() {
                var card = box.closest('.aiyared-import-card');
                var image = card ? card.querySelector('.aiyared-import-image') : null;
                if (image) { image.classList.toggle('opacity-50', !box.checked); }
            });
        });
        form.addEventListener('submit', function(event) {
            var selected = form.querySelectorAll('input[name$="[include]"]:checked').length;
            if (selected === 0) {
                event.preventDefault();
                window.alert({$noselection});
                return;
            }
            var button = document.getElementById('aiyared-import-save');
            if (button) {
                button.disabled = true;
                button.textContent = {$saving};
            }
        }, true);
        document.querySelectorAll('[data-aiyared-confirm]').forEach(function(link) {
            link.addEventListener('click', function(event) {
                if (!window.confirm({$confirm})) {
                    event.preventDefault();
                }
            });
        });

        // Crop editor.
        var dialog = document.getElementById('aiyared-crop-dialog');
        var stage = document.getElementById('aiyared-crop-stage');
        var image = document.getElementById('aiyared-crop-image');
        var selection = document.getElementById('aiyared-crop-selection');
        var label = document.getElementById('aiyared-crop-label');
        var apply = document.getElementById('aiyared-crop-apply');
        var figurebutton = document.getElementById('aiyared-crop-figure');
        var exercisebutton = document.getElementById('aiyared-crop-exercise');
        var active = null;
        var drag = null;
        var MINSIDE = 0.02;
        var PADDING = 0.012;

        function clamp(value, min, max) {
            return Math.max(min, Math.min(max, value));
        }

        function parseBox(value) {
            if (!value) { return null; }
            var box;
            try { box = JSON.parse(value); } catch (e) { return null; }
            if (!Array.isArray(box) || box.length < 4) { return null; }
            var result = [];
            for (var i = 0; i < 4; i++) {
                var number = Number(box[i]);
                if (!isFinite(number)) { return null; }
                result.push(clamp(number, 0, 1));
            }
            if (result[2] - result[0] < MINSIDE || result[3] - result[1] < MINSIDE) {
                return null;
            }
            return result;
        }

        function setSelection(box) {
            if (!box) {
                selection.hidden = true;
                return;
            }
            selection.hidden = false;
            selection.style.left = (box[0] * 100) + '%';
            selection.style.top = (box[1] * 100) + '%';
            selection.style.width = ((box[2] - box[0]) * 100) + '%';
            selection.style.height = ((box[3] - box[1]) * 100) + '%';
        }

        function point(event) {
            var rect = stage.getBoundingClientRect();
            if (!rect.width || !rect.height) {
                return [0, 0];
            }
            return [
                clamp((event.clientX - rect.left) / rect.width, 0, 1),
                clamp((event.clientY - rect.top) / rect.height, 0, 1)
            ];
        }

        function normaliseBox(box) {
            if (!box) { return null; }
            var result = [
                Math.min(box[0], box[2]),
                Math.min(box[1], box[3]),
                Math.max(box[0], box[2]),
                Math.max(box[1], box[3])
            ];
            if (result[2] - result[0] < MINSIDE || result[3] - result[1] < MINSIDE) {
                return null;
            }
            return result;
        }

        function startDrag(event, mode) {
            event.preventDefault();
            drag = {
                mode: mode,
                start: point(event),
                box: active.box ? active.box.slice() : null
            };
            window.addEventListener('pointermove', moveDrag);
            window.addEventListener('pointerup', endDrag);
            try { stage.setPointerCapture(event.pointerId); } catch (e) { /* Ignore. */ }
        }

        function moveDrag(event) {
            if (!drag || !active) { return; }
            var p = point(event);
            var box;
            if (drag.mode === 'draw') {
                box = [drag.start[0], drag.start[1], p[0], p[1]];
            } else if (drag.mode === 'move') {
                var dx = p[0] - drag.start[0];
                var dy = p[1] - drag.start[1];
                box = [
                    drag.box[0] + dx,
                    drag.box[1] + dy,
                    drag.box[2] + dx,
                    drag.box[3] + dy
                ];
                if (box[0] < 0) { box[2] -= box[0]; box[0] = 0; }
                if (box[1] < 0) { box[3] -= box[1]; box[1] = 0; }
                if (box[2] > 1) { box[0] -= (box[2] - 1); box[2] = 1; }
                if (box[3] > 1) { box[1] -= (box[3] - 1); box[3] = 1; }
            } else {
                box = [
                    drag.box[0],
                    drag.box[1],
                    Math.max(drag.box[0] + MINSIDE, p[0]),
                    Math.max(drag.box[1] + MINSIDE, p[1])
                ];
            }
            var normal = normaliseBox(box);
            if (normal) {
                active.box = normal;
                setSelection(normal);
            }
        }

        function endDrag() {
            window.removeEventListener('pointermove', moveDrag);
            window.removeEventListener('pointerup', endDrag);
            if (drag && active && !active.box) {
                selection.hidden = true;
            }
            drag = null;
        }

        stage.addEventListener('pointerdown', function(event) {
            if (!active || event.button !== 0) { return; }
            if (event.target && event.target.getAttribute && event.target.getAttribute('data-handle') === 'se') {
                startDrag(event, 'resize');
                return;
            }
            if (!selection.hidden && selection.contains(event.target)) {
                startDrag(event, 'move');
                return;
            }
            startDrag(event, 'draw');
        });

        function openEditor(button) {
            active = button;
            var index = button.getAttribute('data-index');
            var input = document.getElementById('aiyared-box-' + index);
            var box = parseBox(input ? input.value : '') || parseBox(button.getAttribute('data-box'));
            active.index = index;
            active.box = box;
            active.source = button.getAttribute('data-source');
            active.preview = button.getAttribute('data-preview');
            active.figure = parseBox(button.getAttribute('data-figure'));
            active.exercise = parseBox(button.getAttribute('data-exercise'));
            label.textContent = {$croplabel}.replace('__LABEL__', button.getAttribute('data-label') || '');
            if (active.figure) {
                figurebutton.hidden = false;
                figurebutton.setAttribute('data-box', JSON.stringify(active.figure));
            } else {
                figurebutton.hidden = true;
                figurebutton.removeAttribute('data-box');
            }
            if (active.exercise) {
                exercisebutton.hidden = false;
                exercisebutton.setAttribute('data-box', JSON.stringify(active.exercise));
            } else {
                exercisebutton.hidden = true;
                exercisebutton.removeAttribute('data-box');
            }
            selection.hidden = true;
            image.onload = function() { setSelection(active ? active.box : null); };
            image.src = active.source;
            if (dialog.showModal) {
                if (!dialog.open) { dialog.showModal(); }
            } else {
                dialog.setAttribute('open', 'open');
            }
            if (image.complete && image.naturalWidth) {
                setSelection(active.box);
            }
        }

        function closeEditor() {
            if (!dialog) { return; }
            if (dialog.close) {
                if (dialog.open) { dialog.close(); }
            } else {
                dialog.removeAttribute('open');
            }
            active = null;
            drag = null;
        }

        function previewCrop(preview, source, box, index) {
            if (!preview) { return; }
            var loader = new Image();
            loader.onload = function() {
                var x0 = Math.max(0, box[0] - PADDING);
                var y0 = Math.max(0, box[1] - PADDING);
                var x1 = Math.min(1, box[2] + PADDING);
                var y1 = Math.min(1, box[3] + PADDING);
                var sx = loader.naturalWidth;
                var sy = loader.naturalHeight;
                var cw = Math.max(1, Math.round((x1 - x0) * sx));
                var ch = Math.max(1, Math.round((y1 - y0) * sy));
                var scale = Math.min(1, 1600 / Math.max(cw, ch));
                var canvas = document.createElement('canvas');
                canvas.width = Math.max(1, Math.round(cw * scale));
                canvas.height = Math.max(1, Math.round(ch * scale));
                var context = canvas.getContext('2d');
                if (!context) { return; }
                context.fillStyle = '#ffffff';
                context.fillRect(0, 0, canvas.width, canvas.height);
                context.drawImage(loader, x0 * sx, y0 * sy, cw, ch, 0, 0, canvas.width, canvas.height);
                preview.src = canvas.toDataURL('image/jpeg', 0.9);
                preview.classList.remove('d-none');
                preview.removeAttribute('hidden');
                var wrap = preview.closest('.aiyared-import-image');
                if (wrap) { wrap.classList.remove('opacity-50'); }
                var note = document.getElementById('aiyared-noimage-' + index);
                if (note) { note.classList.add('d-none'); }
            };
            loader.src = source;
        }

        form.querySelectorAll('.aiyared-adjustcrop').forEach(function(button) {
            button.addEventListener('click', function() { openEditor(button); });
        });
        if (dialog) {
            document.getElementById('aiyared-crop-close').addEventListener('click', closeEditor);
            document.getElementById('aiyared-crop-cancel').addEventListener('click', closeEditor);
            dialog.addEventListener('click', function(event) {
                if (event.target === dialog) { closeEditor(); }
            });
            [figurebutton, exercisebutton].forEach(function(button) {
                button.addEventListener('click', function() {
                    if (!active) { return; }
                    var box = parseBox(button.getAttribute('data-box'));
                    if (box) {
                        active.box = box;
                        setSelection(box);
                    }
                });
            });
            apply.addEventListener('click', function() {
                if (!active || !active.box) {
                    window.alert({$croprequired});
                    return;
                }
                var box = active.box.map(function(value) {
                    return Math.round(value * 10000) / 10000;
                });
                var input = document.getElementById('aiyared-box-' + active.index);
                if (input) { input.value = JSON.stringify(box); }
                var use = form.querySelector('input[name="items[' + active.index + '][useimage]"]');
                if (use) { use.checked = true; }
                previewCrop(document.getElementById(active.preview), active.source, box, active.index);
                closeEditor();
            });
        }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
JS;
    $PAGE->requires->js_init_code($js);
}
