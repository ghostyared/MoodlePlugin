# Yared.AI Creador de Material — Constructor de temas y banco de preguntas con IA (Moodle 4.5)

Plugin local que crea con IA el contenido de un tema del curso, genera preguntas para el banco y arma cuestionarios estándar de Moodle con esas preguntas. Todo se abre desde el menú **Más** del curso; **no requiere ningún módulo de actividad adicional**.

## Instalación
1. Subir `local_ai_yared_course.zip` (Extensiones → Instalar plugins).
2. Entrar como administrador para actualizar la base de datos y purgar cachés.
3. **Para recortar figuras de PDFs hace falta Python 3 + PyMuPDF** en el mismo entorno donde corre PHP. Ver la sección *Requisitos de despliegue* de abajo. Sin ellos el plugin sigue funcionando, pero el PDF se analiza solo como texto y no se generan recortes. En *Plugins locales → Yared.AI* hay un bloque **Estado de la conversión de PDF** que indica si el entorno es Docker o un servidor normal y si PyMuPDF está listo.

## Requisitos de despliegue (para soporte)
Antes de entregar un ambiente (QA, producción, otro cliente), revisar esta lista. **PyMuPDF no viene con Moodle ni con el plugin: se instala en cada ambiente.**

| Requisito | Para qué | Si falta |
| --- | --- | --- |
| Moodle 4.5+ y PHP con `proc_open` habilitado (no listado en `disable_functions`) | Ejecutar el convertidor de PDF | Los PDF se analizan solo como texto |
| **Python 3 + PyMuPDF**, accesibles para el usuario del servidor web | Convertir cada página del PDF en imagen y recortar figuras | Aviso «El servidor no pudo convertir el PDF», sin recortes |
| Salida HTTPS hacia el proveedor de IA (Gemini/OpenAI/Grok…) y `googleapis.com` (YouTube) | Generar contenido, preguntas y buscar videos | No se genera nada; ver *Probar la conexión* |
| Tiempo de espera ≥ 600 s en nginx/Apache/PHP-FPM (`proxy_read_timeout`, `fastcgi_read_timeout`, `max_execution_time`) | Generaciones largas | Cortes a mitad de la generación |
| Cron de Moodle activo | Tarea que borra importaciones abandonadas (cada 6 h) | Se acumulan archivos temporales |
| Si un proveedor de IA está en una IP privada (Ollama, etc.): agregar host y puerto en *Seguridad → Seguridad HTTP* de Moodle | Moodle bloquea redes privadas por defecto | El respaldo falla por conexión |

### Moodle en un servidor normal (sin contenedor)
Ubuntu/Debian 24 no permite `pip install` global, por eso se usa un entorno virtual:

```bash
sudo apt install -y python3-venv
sudo python3 -m venv /opt/pymupdf
sudo /opt/pymupdf/bin/pip install PyMuPDF
# Comprobar con el usuario de PHP (debe imprimir una versión):
sudo -u www-data /opt/pymupdf/bin/python -c "import pymupdf; print(pymupdf.__version__)"
```
Luego, en *Administración → Plugins locales → Yared.AI*, poner `/opt/pymupdf/bin/python` en **Python para convertir PDFs**. En servidores Windows: instalar Python 3 y ejecutar `py -m pip install PyMuPDF`; indicar la ruta de `python.exe` en ese mismo ajuste si PHP no la encuentra.

### Moodle en Docker
El Python que cuenta es el **del contenedor de Moodle**, no el del servidor anfitrión. Hay que agregarlo a la **imagen** (Dockerfile) para que no se pierda al recrear el contenedor:

```dockerfile
RUN apt-get update && apt-get install -y python3-venv \
 && python3 -m venv /opt/pymupdf && /opt/pymupdf/bin/pip install PyMuPDF
```
Reconstruir y recrear el contenedor, y comprobar:

```bash
docker exec -u www-data <contenedor> /opt/pymupdf/bin/python -c "import pymupdf; print(pymupdf.__version__)"
```
Después poner `/opt/pymupdf/bin/python` en **Python para convertir PDFs**. Si el contenedor se instaló sin reconstruir la imagen (por ejemplo, con `docker exec ... pip install`), la instalación se perderá al recrearlo.

### Cómo saber si el ambiente está listo
- **Al instalar o actualizar el plugin**, si no se detecta PyMuPDF aparece un aviso amarillo con el enlace a estos pasos.
- **Administración → Informes → Estado** (comprobaciones del sistema): la fila *PyMuPDF para convertir PDFs* queda en verde o en advertencia; sirve para revisar cada ambiente sin abrir el plugin.
- **Estado de la conversión de PDF** (en los ajustes del plugin): debe decir «Listo» con las versiones de Python y PyMuPDF. Muestra también si detectó Docker o servidor normal y las instrucciones que corresponden.
- Si un docente ve el aviso de conversión, el final trae un código: `pymupdf_not_installed` (falta PyMuPDF), `python` (no hay Python 3), `timeout` (servidor saturado), `open_failed` (PDF dañado). Los administradores ven además el detalle y el ambiente (`env=docker` o `env=host`).

## Configuración (administrador)
*Administración del sitio → Extensiones → Plugins locales → Yared.AI Creador de Material*

### Proveedores de IA con respaldo automático
Hay **seis espacios**: el principal y cinco respaldos opcionales. Motores incluidos: Gemini, OpenAI, Grok, DeepSeek, Qwen (DashScope), Kimi (Moonshot), Mistral, Groq, OpenRouter, Zhipu GLM y "Otro compatible con OpenAI" (verifique el nombre del modelo vigente en cada proveedor). Cada uno tiene su proveedor, clave API, modelo, URL base y modo JSON. El plugin usa el principal y, si falla por cuota, conexión, clave o modelo retirado, prueba los respaldos 1 a 5 en orden. El último proveedor que funcionó se recuerda para el resto del lote.

- **Principal**: Gemini (por defecto `gemini-3.5-flash-lite`, recomendado para leer PDFs e imágenes), OpenAI, Grok u otro compatible con OpenAI.
- **Respaldo 1 a 5**: opcionales. Se activan con la casilla **Activar este proveedor**.
- Cada proveedor tiene su botón **Probar la conexión**; el principal también prueba YouTube. Probar consume una solicitud de la cuota.
- La temperatura, el tiempo de espera y las preguntas por solicitud son generales para los tres. Para PDFs e imágenes se recomiendan 600 s de espera.
- Si un modelo dejó de existir (error 404), cámbielo por uno vigente. Puede consultar los modelos disponibles de Gemini en `https://generativelanguage.googleapis.com/v1beta/models?key=TU_API_KEY` y usar los que incluyan `generateContent`.
- Ejemplos de respaldo: Gemini Lite, Groq/Cerebras (compatibles con OpenAI), DeepSeek (`https://api.deepseek.com/v1` + `deepseek-chat`), Ollama local (`http://IP:11434/v1`) u OpenRouter.
- La tabla de resultados del lote muestra qué proveedor se usó y una advertencia si hubo que cambiar de proveedor durante el tema.

- **Edad de cada nivel**: edad que se envía a la IA para Inicial, Primaria, Secundaria y Universitario.
- **Clave de la API de YouTube Data v3**: necesaria para buscar videos reales. Sin clave se crea un marcador oculto.

## Uso (docente)
Curso → menú **Más**:
- **Yared.AI Creador de Material**: pide dónde agregar los temas (una sección nueva por cada tema o una sección existente), la cantidad (1 a 10), la lista de temas con su dificultad/edad y fecha, y qué componentes crear: video, banco de preguntas, práctica calificada y trabajo de investigación. Luego crea todos los temas en un solo lote y muestra el avance en vivo.
- **Yared.AI Creador de Pregunta**: elige una de las tres formas: **Clásico**, **Matemáticas con LaTeX** o **Desde PDF o imagen**. Las dos primeras generan preguntas y las guardan en el banco del curso. Al enviar el formulario muestra una pantalla de espera con los pasos y el tiempo transcurrido; no cierre ni recargue la ventana. La cuarta tarjeta, **Crear cuestionario**, abre el asistente de cuestionarios.
- **Desde PDF o imagen**: sube PDFs o fotos con varios ejercicios. La IA los separa y transcribe cada enunciado. Si hay Python/PyMuPDF, cada página del PDF se convierte en imagen y también se recorta la figura; si no, el PDF se procesa solo como texto. Antes de guardar puedes revisar, editar y ajustar cada recorte. Si el PDF no se separa bien, sube una imagen por pregunta (hasta 10).
- **Yared.AI Creador de Cuestionario**: elige uno o varios bancos (muestra cuántas preguntas tiene cada uno), el nombre, la descripción, la cantidad (10 por defecto) y la sección. Las subsecciones de Formato-Mariategui aparecen indentadas con ↳ debajo de su sección principal, para que se pueda colocar el cuestionario dentro de un tema. Crea un **cuestionario estándar de Moodle** con 2 intentos, calificación más alta, 30 minutos, todas las preguntas en una página, 20 puntos y preguntas aleatorias distintas en cada intento, repartidas entre los bancos. Después se edita con el editor normal de cuestionarios; no crea un módulo de actividad nuevo.

Cada tema creado incluye: encabezado con 🚀 Tema y 🚀 Fecha · 🎯 Lo que vas a aprender (resumen y objetivos) · 🎥 Video de Apoyo · 📖 Material Didáctico (PDF) · 📝 Práctica Calificada (cuestionario calificado sobre 20, amarrado al banco de preguntas del tema) · 📝 Práctica de Extensión (tarea de investigación con texto en línea y archivos PDF, PPTX, DOC o DOCX).

El ítem "Yared.AI Creador de Pregunta" de la sección es un **enlace** al banco del curso, filtrado por la categoría de ese tema. La práctica calificada se crea **oculta** para que el docente la revise; el trabajo de investigación queda como tarea visible dentro de la sección. El video y el PDF se crean ocultos solo si no se pudieron generar; si el PDF completo falla, se crea un PDF de respaldo con el resumen, los objetivos y las ideas clave (nunca un archivo en blanco). La sección nueva también se crea oculta para revisarla.

## Matemáticas, LaTeX e imágenes
En **Yared.AI Creador de Pregunta**:
- Elige la tarjeta **Matemáticas con LaTeX** para que la IA escriba las fórmulas con `\( ... \)` (en línea) y `\[ ... \]` (destacadas). El filtro **MathJax** o **TeX** debe estar activo en Moodle para que se vean (*Administración del sitio → Extensiones → Filtros*); si no lo está, las preguntas se guardan igual y se muestra una advertencia.
- El campo **Instrucciones adicionales** permite pedir, por ejemplo, identidades trigonométricas, ejercicios de ángulos, nivel de dificultad o al menos dos pasos algebraicos. La IA debe seguir devolviendo el mismo JSON. Este campo y las opciones de imagen están disponibles en **Matemáticas con LaTeX**; en **Clásico** no se muestran.
- Marca **Permitir imágenes** para aceptar imágenes en la pregunta y en las alternativas. Puede escribir una **URL por línea** en el campo de URLs (se asignan en orden a las preguntas) o dejar que la IA proponga una URL real. La IA de texto no dibuja diagramas: si no tiene una URL, indícala tú.
- El plugin descarga la imagen, comprueba que sea PNG, JPG, GIF o WebP (máximo 2 MB y dimensiones razonables) y la guarda como **archivo de la pregunta** en el banco. Las alternativas también aceptan imagen.
- **Base64:** Moodle elimina las imágenes `data:` del HTML por seguridad, así que no se insertan como base64 en el texto. El campo de URLs acepta `data:image/png;base64,...` como entrada y el plugin la convierte en archivo del banco. Así la pregunta funciona al exportar, importar y hacer copias de seguridad.
- Por seguridad, solo se descargan URLs públicas por HTTP/HTTPS en los puertos 80/443; se bloquean localhost, redes privadas, redirecciones y archivos que no sean imágenes. Las URLs de imagen propuestas por la IA deben ser reales; si fallan, la pregunta se guarda sin esa imagen y se muestra una advertencia.

## Importar preguntas desde PDF o imágenes
En **Yared.AI Creador de Pregunta**, pulse **Crear preguntas desde PDF o imagen**.
- Hasta 10 archivos: PDFs de hasta 15 páginas y 12 MB, o imágenes PNG, JPG, GIF o WebP de hasta 10 MB. El lote se limita a 20 ejercicios.
- Se usan el proveedor principal y los respaldos configurados. Si el PDF no se separa bien, sube **una imagen por pregunta** (hasta 10): cada imagen se recorta y genera una pregunta. También puedes subir una sola imagen de la página completa para que la IA separe los ejercicios.
- Si el servidor tiene Python y PyMuPDF, cada página del PDF se convierte en imagen y se recorta igual que una foto. Si no, el PDF se envía tal cual: se conservan el texto y las alternativas, pero no se generan recortes y se muestra una advertencia.
- En las imágenes se recorta la figura detectada o, si no hay figura, el ejercicio completo (opcional).
- Antes de guardar se muestra una pantalla de revisión: puedes editar el enunciado, las alternativas, la respuesta correcta, la retroalimentación y el texto alternativo de la imagen, además de excluir preguntas del lote.
- Elige una categoría existente o crea una nueva. Las imágenes se guardan como **archivos de la pregunta**, no como base64.
- Esta versión guarda las preguntas en el banco; no crea la práctica calificada ni el cuestionario.

## API externa
Las funciones `local_ai_yared_course_create_course`, `_create_topic`, `_list_courses`, `_list_topics` y `_update_syllabus` están registradas en `db/services.php`. La generación usa el mismo conjunto de proveedor principal y respaldos; la app no necesita cambiar nada.

## Notas
- El proceso normalmente tarda unos segundos con un modelo flash-lite; puede llegar a varios minutos si el proveedor está lento o debe probar respaldos. El tiempo de espera recomendado es 600 s. Si usa nginx, suba `proxy_read_timeout`/`fastcgi_read_timeout` a 600 s. La página muestra el avance paso a paso.
- En **Yared.AI Creador de Pregunta**, la pantalla de espera se queda abierta hasta que el servidor termina. No cierre ni recargue la ventana; si el navegador o el proxy cortan la conexión, la generación puede quedar incompleta.
- Los textos son generados por IA: revíselos antes de publicar.
- Los bloques usan estilos en línea; si el docente los edita con el editor, algunos estilos pueden simplificarse.

### Creador de Material: opciones nuevas (0.13.0)
- **¿Dónde agregarlo?** Tarjetas para elegir; por defecto *En una sección existente* (primera sección vacía).
- **Crear PDF de la clase**: solo se genera el PDF si se marca.
- **Práctica Calificada**: todas las preguntas en una sola página (Nueva página: Nunca).
- **Crear Foro de discusión**: la IA escribe una pregunta según la edad; se publica como primera discusión. Calificación del foro completo: Puntuación, máximo 20 pts.

### Proceso en segundo plano (0.14.0)
- **Yared.AI Creador de Material** ya no se ejecuta dentro de la ventana: al pulsar *Crear* se guarda un trabajo (tabla `local_ai_yared_course_job`) y una **tarea ad hoc** de Moodle lo ejecuta con el cron, **con el usuario del docente** (sus permisos y sus borradores). Cada docente solo ve y cancela sus propios trabajos (los administradores pueden verlos todos).
- El docente puede cerrar la ventana o cambiar de pestaña; el avance se retoma en `job.php` (barra, pasos, botón **Cancelar proceso**, resumen final) desde el aviso o desde *Procesos recientes* del formulario.
- Un docente ejecuta **un trabajo a la vez**; docentes distintos pueden trabajar en paralelo según los procesos de cron disponibles.
- **Requisito:** el cron de Moodle debe ejecutarse cada minuto (en Docker, un contenedor o servicio de cron). Si no corre, el trabajo se marca con error tras 60 min en cola. Un trabajo sin avance por 30 min se marca con error. Los trabajos con más de 30 días se eliminan solos.
- Al cancelar, lo ya creado se mantiene en el curso.

### Índice de temas en secciones existentes (0.14.1)
Cuando los temas se agregan a una **sección existente**, el plugin crea (y mantiene actualizado) al inicio de la sección un recuadro **"Temas de esta sección"** con un enlace por tema (título y fecha) que salta directo a él. Se reconstruye a partir de los encabezados de tema de la sección, así que también incluye los temas creados antes y se corrige si se borran o reordenan. Con una sección nueva por tema no se crea. Moodle 4.5 no tiene subsecciones; en Moodle 5.0 o con el formato Flexsections se podría plegar cada tema (pendiente).

### Temas como subsecciones en acordeón con Formato-Mariategui (0.15.2)
Si el curso usa el formato **Formato-Mariategui** (`format_flextiles`) y se elige una sección existente, cada tema se crea como **subsección hija en modo acordeón**: el tema y sus actividades se abren dentro de la sección elegida, sin abrir otra página. La opción **Crear cada tema como subsección en acordeón** aparece marcada por defecto; se puede desmarcar para agregar los temas al final de la sección con el índice de enlaces.
- El plugin guarda la subsección con `displaymode=accordion`, que Formato-Mariategui traduce a una sección expandida.
- El enlace **Ir a la sección** del informe apunta a la sección padre, donde se ve el acordeón.
- La sección **General** (número 0) no admite subsecciones: en ese caso los temas se agregan al final con el índice.
- Si el formato no puede colocar la subsección dentro de la sección elegida, la app elimina la sección huérfana y usa el índice de respaldo.
- Si Formato-Mariategui no está instalado o el curso usa otro formato, se mantiene el comportamiento anterior (Flexsections plegado, Moodle 5 o índice de enlaces).

### Temas como subsecciones plegadas (0.15.0)
Al agregar temas a una **sección existente**, el plugin detecta qué se puede usar:
- **Formato Flexsections** (`format_flexsections`) en el curso, en Moodle 4.x o 5.x: cada tema se crea como subsección hija de la sección elegida, con el nombre "Título — fecha" y **plegada** (el padre solo muestra el título como enlace y el tema abre en su propia página).
- **Moodle 5.0+** con la actividad *Subsección* (mod_subsection) y un formato que la admita: cada tema se crea como una subsección.
- **Moodle 4.x sin Flexsections** (o con Flexsections instalado pero el curso en otro formato): el formulario avisa qué instalar o cambiar, y los temas se agregan como antes con el índice de enlaces.
Se puede desmarcar *Crear cada tema como subsección plegada* en el formulario. Si la subsección falla, el tema se crea igual al final de la sección elegida.
