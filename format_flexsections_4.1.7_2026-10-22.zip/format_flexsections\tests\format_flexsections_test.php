<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace format_flexsections;

use context_course;
use core_external;
use external_api;
use moodle_exception;
use moodle_url;
use testable_course_edit_form;

/**
 * Flexible sections course format related unit tests.
 *
 * @package    format_flexsections
 * @copyright  2022 Marina Glancy
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \format_flexsections
 */
final class format_flexsections_test extends \advanced_testcase {
    /**
     * Shared setup for the testcase.
     */
    public function setUp(): void {
        global $CFG;
        require_once($CFG->dirroot . '/course/lib.php');
        parent::setUp();
    }

    /**
     * Tests for format_flexsections::get_section_name method with default section names.
     */
    public function test_get_section_name(): void {
        global $DB;
        $this->resetAfterTest(true);

        // Generate a course with 5 sections.
        $generator = $this->getDataGenerator();
        $numsections = 5;
        $course = $generator->create_course(
            ['numsections' => $numsections, 'format' => 'flexsections'],
            ['createsections' => true]
        );

        // Get section names for course.
        $coursesections = $DB->get_records('course_sections', ['course' => $course->id]);

        // Test get_section_name with default section names.
        $courseformat = course_get_format($course);
        foreach ($coursesections as $section) {
            // Assert that with unmodified section names, get_section_name returns the same result as get_default_section_name.
            $this->assertEquals($courseformat->get_default_section_name($section), $courseformat->get_section_name($section));
        }
    }

    /**
     * Tests for format_flexsections::get_section_name method with modified section names.
     *
     * @return void
     */
    public function test_get_section_name_customised(): void {
        global $DB;
        $this->resetAfterTest(true);

        // Generate a course with 5 sections.
        $generator = $this->getDataGenerator();
        $numsections = 5;
        $course = $generator->create_course(
            ['numsections' => $numsections, 'format' => 'flexsections'],
            ['createsections' => true]
        );

        // Get section names for course.
        $coursesections = $DB->get_records('course_sections', ['course' => $course->id]);

        // Modify section names.
        $customname = "Custom Section";
        foreach ($coursesections as $section) {
            $section->name = "$customname $section->section";
            $DB->update_record('course_sections', $section);
        }

        // Requery updated section names then test get_section_name.
        $coursesections = $DB->get_records('course_sections', ['course' => $course->id]);
        $courseformat = course_get_format($course);
        foreach ($coursesections as $section) {
            // Assert that with modified section names, get_section_name returns the modified section name.
            $this->assertEquals($section->name, $courseformat->get_section_name($section));
        }
    }

    /**
     * Tests for format_flexsections::get_default_section_name.
     *
     * @return void
     */
    public function test_get_default_section_name(): void {
        global $DB;
        $this->resetAfterTest(true);

        // Generate a course with 5 sections.
        $generator = $this->getDataGenerator();
        $numsections = 5;
        $course = $generator->create_course(
            ['numsections' => $numsections, 'format' => 'flexsections'],
            ['createsections' => true]
        );

        // Get section names for course.
        $coursesections = $DB->get_records('course_sections', ['course' => $course->id]);

        // Test get_default_section_name with default section names.
        $courseformat = course_get_format($course);
        foreach ($coursesections as $section) {
            if ($section->section == 0) {
                $sectionname = get_string('section0name', 'format_flexsections');
                $this->assertEquals($sectionname, $courseformat->get_default_section_name($section));
            } else {
                $sectionname = get_string('sectionname', 'format_flexsections') . ' ' . $section->section;
                $this->assertEquals($sectionname, $courseformat->get_default_section_name($section));
            }
        }
    }

    /**
     * Test web service updating section name.
     *
     * @runInSeparateProcess
     * @return void
     */
    public function test_update_inplace_editable(): void {
        global $CFG, $DB, $PAGE;
        require_once($CFG->dirroot . '/lib/external/externallib.php');

        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $this->setUser($user);
        $course = $this->getDataGenerator()->create_course(
            ['numsections' => 5, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $section = $DB->get_record('course_sections', ['course' => $course->id, 'section' => 2]);

        // Call webservice without necessary permissions.
        try {
            core_external::update_inplace_editable('format_flexsections', 'sectionname', $section->id, 'New section name');
            $this->fail('Exception expected');
        } catch (moodle_exception $e) {
            $this->assertEquals(
                'Course or activity not accessible. (Not enrolled)',
                $e->getMessage()
            );
        }

        // Change to teacher and make sure that section name can be updated using web service update_inplace_editable().
        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher']);
        $this->getDataGenerator()->enrol_user($user->id, $course->id, $teacherrole->id);

        $res = core_external::update_inplace_editable('format_flexsections', 'sectionname', $section->id, 'New section name');
        $res = external_api::clean_returnvalue(core_external::update_inplace_editable_returns(), $res);
        $this->assertEquals('New section name', $res['value']);
        $this->assertEquals('New section name', $DB->get_field('course_sections', 'name', ['id' => $section->id]));
    }

    /**
     * Test callback updating section name.
     *
     * @runInSeparateProcess
     * @return void
     */
    public function test_inplace_editable(): void {
        global $DB, $PAGE;

        $this->resetAfterTest();
        $user = $this->getDataGenerator()->create_user();
        $course = $this->getDataGenerator()->create_course(
            ['numsections' => 5, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher']);
        $this->getDataGenerator()->enrol_user($user->id, $course->id, $teacherrole->id);
        $this->setUser($user);

        $section = $DB->get_record('course_sections', ['course' => $course->id, 'section' => 2]);

        // Call callback format_flexsections_inplace_editable() directly.
        $tmpl = component_callback(
            'format_flexsections',
            'inplace_editable',
            ['sectionname', $section->id, 'Rename me again']
        );
        $this->assertInstanceOf('core\output\inplace_editable', $tmpl);
        $res = $tmpl->export_for_template($PAGE->get_renderer('core'));
        $this->assertEquals('Rename me again', $res['value']);
        $this->assertEquals('Rename me again', $DB->get_field('course_sections', 'name', ['id' => $section->id]));

        // Try updating using callback from mismatching course format.
        try {
            component_callback('format_weeks', 'inplace_editable', ['sectionname', $section->id, 'New name']);
            $this->fail('Exception expected');
        } catch (moodle_exception $e) {
            $this->assertEquals(1, preg_match('/^Can\'t find data record in database/', $e->getMessage()));
        }
    }

    /**
     * Test get_default_course_enddate.
     *
     * @return void
     */
    public function test_default_course_enddate(): void {
        global $CFG, $DB;

        $this->resetAfterTest(true);

        require_once($CFG->dirroot . '/course/tests/fixtures/testable_course_edit_form.php');

        $this->setTimezone('UTC');

        $params = ['format' => 'flexsections', 'numsections' => 5, 'startdate' => 1445644800];
        $course = $this->getDataGenerator()->create_course($params);
        $category = $DB->get_record('course_categories', ['id' => $course->category]);

        $args = [
            'course' => $course,
            'category' => $category,
            'editoroptions' => [
                'context' => context_course::instance($course->id),
                'subdirs' => 0,
            ],
            'returnto' => new moodle_url('/'),
            'returnurl' => new moodle_url('/'),
        ];

        $courseform = new testable_course_edit_form(null, $args);
        $courseform->definition_after_data();

        $enddate = $params['startdate'] + get_config('moodlecourse', 'courseduration');

        $format = course_get_format($course->id);
        $this->assertEquals($enddate, $format->get_default_course_enddate($courseform->get_quick_form()));
    }

    /**
     * Test for get_view_url() to ensure that the url is only given for the correct cases.
     *
     * @return void
     */
    public function test_get_view_url(): void {
        global $CFG;
        $this->resetAfterTest();

        // Generate a course with two sections (0 and 1) and two modules.
        $generator = $this->getDataGenerator();
        $course1 = $generator->create_course(['format' => 'flexsections']);
        course_create_sections_if_missing($course1, [0, 1]);

        $data = (object)['id' => $course1->id];
        /** @var \format_flexsections $format */
        $format = course_get_format($course1);
        $format->update_course_format_options($data);

        $this->assertNotEmpty($format->get_view_url(null));
        $this->assertNotEmpty($format->get_view_url(0));
        $this->assertNotEmpty($format->get_view_url(1));
    }

    /**
     * Test get_view_url() with null section when section number is set.
     *
     * Regression test for https://github.com/marinaglancy/moodle-format_flexsections/issues/109
     * When viewing a single section page and get_view_url is called with null,
     * it should not produce a warning about reading property on null.
     *
     * @return void
     */
    public function test_get_view_url_with_section_number_set(): void {
        $this->resetAfterTest();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['format' => 'flexsections']);
        course_create_sections_if_missing($course, [0, 1]);

        /** @var \format_flexsections $format */
        $format = course_get_format($course);

        // Simulate being on a single section page by setting the section number.
        $format->set_section_number(1);

        // This should not produce a PHP warning "Attempt to read property 'id' on null".
        $url = $format->get_view_url(null);
        $this->assertNotEmpty($url);

        // Also test with navigation option.
        $url = $format->get_view_url(null, ['navigation' => true]);
        $this->assertTrue($url === null || $url instanceof moodle_url);
    }

    /**
     * Tests for format_flexsections::delete_section_with_children.
     */
    public function test_delete_section_with_children(): void {
        global $DB;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        // Generate a course with 5 sections.
        $generator = $this->getDataGenerator();
        $numsections = 5;
        $course = $generator->create_course(
            ['numsections' => $numsections, 'format' => 'flexsections'],
            ['createsections' => true]
        );

        // Get last section.
        $courseformat = course_get_format($course);
        $sections = $courseformat->get_sections();
        $lastsection = array_pop($sections);

        // Create 2 subsections.
        $this->assertEquals(6, $courseformat->create_new_section($lastsection->section));
        $this->assertEquals(7, $courseformat->create_new_section($lastsection->section));
        // Sanity check, expect 8 sections in total (section 0-7).
        $this->assertCount(8, $courseformat->get_sections());

        // Delete last top section, this should delete 3 sections in total.
        $sink = $this->redirectEvents();
        $courseformat->delete_section_with_children($lastsection);

        // Check events.
        $events = $sink->get_events();
        $this->assertCount(3, $events);
        foreach ($events as $event) {
            $this->assertInstanceOf('\core\event\course_section_deleted', $event);
            $this->assertContains((int) $event->get_data()['other']['sectionnum'], [5, 6, 7]);
        }
        // Sanity check, expect 5 sections in total (section 0-4).
        $this->assertCount(5, $courseformat->get_sections());
    }

    /**
     * Deleting a subsection when the maximum depth is lower than the existing depth of subsections.
     *
     * Only the subsection and its children may be deleted, the following sections must stay.
     */
    public function test_delete_subsection_with_max_depth(): void {
        global $DB;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['numsections' => 0, 'format' => 'flexsections']);
        /** @var \format_flexsections_generator $flexgenerator */
        $flexgenerator = $generator->get_plugin_generator('format_flexsections');
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S1', 'parent' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S11', 'parent' => 'S1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S2', 'parent' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T2']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T3']);
        $sectionnum = fn(string $name) => (int)$DB->get_field(
            'course_sections',
            'section',
            ['course' => $course->id, 'name' => $name],
            MUST_EXIST
        );
        foreach (['S1', 'S11', 'S2', 'T2', 'T3'] as $name) {
            $generator->create_module('page', ['course' => $course->id, 'section' => $sectionnum($name), 'name' => "P$name"]);
        }
        $this->assertEquals(['T1', 'S1', 'S11', 'S2', 'T2', 'T3'], $this->get_section_names($course->id));

        // Lower the max depth after the subsections were created and highlight the last section.
        set_config('maxsectiondepth', 1, 'format_flexsections');
        /** @var \format_flexsections $format */
        $format = course_get_format($course->id);
        $format->section_action($format->get_section($sectionnum('T3')), 'setmarker', 0);
        $this->assertEquals($sectionnum('T3'), $DB->get_field('course', 'marker', ['id' => $course->id]));

        // Subsections can still be moved to the top level.
        $this->assertTrue($format->can_move_section_to($format->get_section($sectionnum('S2')), 0));

        [$deletedsections, $deletedcms] = $format->delete_section_with_children($format->get_section($sectionnum('S1')));

        $this->assertCount(2, $deletedsections);
        $this->assertCount(2, $deletedcms);
        $this->assertEquals(['T1', 'S2', 'T2', 'T3'], $this->get_section_names($course->id));
        $modinfo = get_fast_modinfo($course->id);
        $this->assertEquals($sectionnum('T1'), $modinfo->get_section_info($sectionnum('S2'))->parent);
        $this->assertEquals(0, $modinfo->get_section_info($sectionnum('T2'))->parent);
        $cmnames = array_values(array_map(fn($cm) => $cm->name, $modinfo->get_cms()));
        sort($cmnames);
        $this->assertEquals(['PS2', 'PT2', 'PT3'], $cmnames);
        // The highlighted section is still the same.
        $this->assertEquals($sectionnum('T3'), $DB->get_field('course', 'marker', ['id' => $course->id]));

        // Deleting the highlighted section removes the marker.
        $format = course_get_format($course->id);
        $format->section_action($format->get_section($sectionnum('S2')), 'setmarker', 0);
        $this->assertEquals($sectionnum('S2'), $DB->get_field('course', 'marker', ['id' => $course->id]));
        $format->delete_section_with_children($format->get_section($sectionnum('S2')));
        $this->assertEquals(['T1', 'T2', 'T3'], $this->get_section_names($course->id));
        $this->assertEquals(0, $DB->get_field('course', 'marker', ['id' => $course->id]));
    }

    /**
     * Deleting a section that can not be moved to the end of the course must not delete other sections.
     */
    public function test_delete_section_without_permission(): void {
        global $DB;
        $this->resetAfterTest(true);

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(
            ['numsections' => 3, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $format = course_get_format($course->id);

        try {
            $format->delete_section_with_children($format->get_section(1));
            $this->fail('Exception expected');
        } catch (moodle_exception $e) {
            $this->assertEquals('nopermissions', $e->errorcode);
        }
        $this->assertEquals(4, $DB->count_records('course_sections', ['course' => $course->id]));
    }

    /**
     * Merging a section with its parent.
     */
    public function test_mergeup_section(): void {
        global $DB;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['numsections' => 0, 'format' => 'flexsections']);
        /** @var \format_flexsections_generator $flexgenerator */
        $flexgenerator = $generator->get_plugin_generator('format_flexsections');
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S1', 'parent' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S11', 'parent' => 'S1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T2']);
        $generator->create_module('page', ['course' => $course->id, 'section' => 1, 'name' => 'PT1']);
        $generator->create_module('page', ['course' => $course->id, 'section' => 2, 'name' => 'PS1']);
        $this->assertEquals(['T1', 'S1', 'S11', 'T2'], $this->get_section_names($course->id));

        /** @var \format_flexsections $format */
        $format = course_get_format($course->id);
        $format->section_action($format->get_section(2), 'setmarker', 0);
        $this->assertEquals(2, $DB->get_field('course', 'marker', ['id' => $course->id]));

        $sectionid = $format->get_section(2)->id;
        $sink = $this->redirectEvents();
        $format->mergeup_section($format->get_section(2));
        $events = array_values(array_filter(
            $sink->get_events(),
            fn($event) => $event instanceof \core\event\course_section_deleted
        ));
        $this->assertCount(1, $events);
        $this->assertEquals($sectionid, $events[0]->objectid);

        $this->assertEquals(['T1', 'S11', 'T2'], $this->get_section_names($course->id));
        $modinfo = get_fast_modinfo($course->id);
        $this->assertEquals(1, $modinfo->get_section_info(2)->parent);
        $this->assertEquals(['PT1', 'PS1'], array_map(fn($cmid) => $modinfo->get_cm($cmid)->name, $modinfo->sections[1]));
        $this->assertEquals(0, $DB->get_field('course', 'marker', ['id' => $course->id]));
    }

    /**
     * Sections with activities that the user can not delete can not be deleted.
     */
    public function test_section_delete_protected_activity(): void {
        global $DB;
        $this->resetAfterTest(true);

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(
            ['numsections' => 2, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $teacher = $generator->create_and_enrol($course, 'editingteacher');
        $page = $generator->create_module('page', ['course' => $course->id, 'section' => 1]);
        $roleid = $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        assign_capability('moodle/course:manageactivities', CAP_PROHIBIT, $roleid, \context_module::instance($page->cmid)->id);
        $this->setUser($teacher);

        $format = course_get_format($course);
        $actions = new \format_flexsections\courseformat\stateactions();
        $actions->section_delete(new \core_courseformat\stateupdates($format), $course, [$format->get_section(1)->id]);
        $this->assertEquals(3, $DB->count_records('course_sections', ['course' => $course->id]));
        $this->assertTrue($DB->record_exists('course_modules', ['id' => $page->cmid]));

        $actions->section_delete(new \core_courseformat\stateupdates($format), $course, [$format->get_section(2)->id]);
        $this->assertEquals(2, $DB->count_records('course_sections', ['course' => $course->id]));
    }

    /**
     * Sections can not be deleted if their subsections contain activities that the user can not delete.
     */
    public function test_section_delete_protected_activity_in_subsection(): void {
        global $DB;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['numsections' => 0, 'format' => 'flexsections']);
        /** @var \format_flexsections_generator $flexgenerator */
        $flexgenerator = $generator->get_plugin_generator('format_flexsections');
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S1', 'parent' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S11', 'parent' => 'S1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T2']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S2', 'parent' => 'T2']);
        $page = $generator->create_module('page', ['course' => $course->id, 'section' => 3]);
        $generator->create_module('page', ['course' => $course->id, 'section' => 5]);

        $teacher = $generator->create_and_enrol($course, 'editingteacher');
        $roleid = $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        assign_capability('moodle/course:manageactivities', CAP_PROHIBIT, $roleid, \context_module::instance($page->cmid)->id);
        $this->setUser($teacher);

        $format = course_get_format($course);
        $this->assertFalse(course_can_delete_section($course, $format->get_section(1)));
        $this->assertFalse(course_can_delete_section($course, $format->get_section(2)));
        $this->assertFalse(course_can_delete_section($course, $format->get_section(3)));
        $this->assertTrue(course_can_delete_section($course, $format->get_section(4)));

        $actions = new \format_flexsections\courseformat\stateactions();
        $actions->section_delete(new \core_courseformat\stateupdates($format), $course, [$format->get_section(1)->id]);
        $this->assertEquals(['T1', 'S1', 'S11', 'T2', 'S2'], $this->get_section_names($course->id));
        $this->assertTrue($DB->record_exists('course_modules', ['id' => $page->cmid]));

        $format = course_get_format($course);
        $actions->section_delete(new \core_courseformat\stateupdates($format), $course, [$format->get_section(4)->id]);
        $this->assertEquals(['T1', 'S1', 'S11'], $this->get_section_names($course->id));
    }

    /**
     * Sections can not be merged with their parent if they contain activities that the user can not manage.
     */
    public function test_mergeup_protected_activity(): void {
        global $DB;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['numsections' => 0, 'format' => 'flexsections']);
        /** @var \format_flexsections_generator $flexgenerator */
        $flexgenerator = $generator->get_plugin_generator('format_flexsections');
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S1', 'parent' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S2', 'parent' => 'T1']);
        $page = $generator->create_module('page', ['course' => $course->id, 'section' => 2]);
        $generator->create_module('page', ['course' => $course->id, 'section' => 3]);

        $teacher = $generator->create_and_enrol($course, 'editingteacher');
        $roleid = $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        assign_capability('moodle/course:manageactivities', CAP_PROHIBIT, $roleid, \context_module::instance($page->cmid)->id);
        $this->setUser($teacher);

        /** @var \format_flexsections $format */
        $format = course_get_format($course);
        $this->assertFalse($format->can_mergeup_section($format->get_section(1)));
        $this->assertFalse($format->can_mergeup_section($format->get_section(2)));
        $this->assertTrue($format->can_mergeup_section($format->get_section(3)));

        $actions = new \format_flexsections\courseformat\stateactions();
        try {
            $actions->section_mergeup(new \core_courseformat\stateupdates($format), $course, [], $format->get_section(2)->id);
            $this->fail('Exception expected');
        } catch (moodle_exception $e) {
            $this->assertEquals('nopermissions', $e->errorcode);
        }
        $this->assertEquals(['T1', 'S1', 'S2'], $this->get_section_names($course->id));

        $actions->section_mergeup(new \core_courseformat\stateupdates($format), $course, [], $format->get_section(3)->id);
        $this->assertEquals(['T1', 'S1'], $this->get_section_names($course->id));
    }

    /**
     * Merging and moving sections require the capability to move sections.
     */
    public function test_mergeup_and_move_require_movesections(): void {
        global $DB, $PAGE;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['numsections' => 0, 'format' => 'flexsections']);
        /** @var \format_flexsections_generator $flexgenerator */
        $flexgenerator = $generator->get_plugin_generator('format_flexsections');
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'T1']);
        $flexgenerator->create_section(['courseid' => $course->id, 'name' => 'S1', 'parent' => 'T1']);
        $PAGE->set_url(new moodle_url('/course/view.php', ['id' => $course->id]));

        $teacher = $generator->create_and_enrol($course, 'editingteacher');
        $roleid = $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        assign_capability('moodle/course:movesections', CAP_PROHIBIT, $roleid, context_course::instance($course->id)->id);

        /** @var \format_flexsections $format */
        $format = course_get_format($course);
        $getcontrols = fn(int $sectionnum): array =>
            (new \format_flexsections\output\courseformat\content\section\controlmenu(
                $format,
                $format->get_section($sectionnum)
            ))->section_control_items();

        // Admin can merge and move sections.
        $this->assertEquals(['T1', 'S1'], $this->get_section_names($course->id));
        $this->assertEquals(1, $format->get_section(2)->parent);
        $this->assertTrue($format->can_mergeup_section($format->get_section(2)));
        $this->assertArrayHasKey('mergeup', $getcontrols(2));
        $this->assertArrayHasKey('moveflexsections', $getcontrols(2));

        // Teacher without the capability to move sections can not merge or move sections.
        $this->setUser($teacher);
        $this->assertFalse($format->can_mergeup_section($format->get_section(2)));
        $this->assertArrayNotHasKey('mergeup', $getcontrols(2));
        $this->assertArrayNotHasKey('moveflexsections', $getcontrols(1));
        $this->assertArrayNotHasKey('moveflexsections', $getcontrols(2));

        $actions = new \format_flexsections\courseformat\stateactions();
        try {
            $actions->section_mergeup(new \core_courseformat\stateupdates($format), $course, [], $format->get_section(2)->id);
            $this->fail('Exception expected');
        } catch (moodle_exception $e) {
            $this->assertEquals('nopermissions', $e->errorcode);
        }
        $this->assertEquals(['T1', 'S1'], $this->get_section_names($course->id));
    }

    /**
     * Adding a section in the middle of the course requires the capability to move sections.
     */
    public function test_section_add_requires_movesections(): void {
        global $DB;
        $this->resetAfterTest(true);

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(
            ['numsections' => 2, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $teacher = $generator->create_and_enrol($course, 'editingteacher');
        $roleid = $DB->get_field('role', 'id', ['shortname' => 'editingteacher']);
        assign_capability('moodle/course:movesections', CAP_PROHIBIT, $roleid, context_course::instance($course->id)->id);
        $this->setUser($teacher);

        $format = course_get_format($course);
        $actions = new \format_flexsections\courseformat\stateactions();
        $actions->section_add(new \core_courseformat\stateupdates($format), $course);
        $this->assertEquals(4, $DB->count_records('course_sections', ['course' => $course->id]));

        $this->expectException(\required_capability_exception::class);
        $actions->section_add(new \core_courseformat\stateupdates($format), $course, [], $format->get_section(1)->id);
    }

    /**
     * Broken parent references do not cause infinite recursion.
     */
    public function test_broken_parent(): void {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course(
            ['numsections' => 3, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        /** @var \format_flexsections $format */
        $format = course_get_format($course);

        // Create a cycle: section 2 is a child of section 3 and section 3 is a child of section 2.
        $format->update_section_format_options(['id' => $format->get_section(2)->id, 'parent' => 3]);
        $format->update_section_format_options(['id' => $format->get_section(3)->id, 'parent' => 2]);
        rebuild_course_cache($course->id, true);

        $format = course_get_format($course);
        $this->assertEquals(1, $format->get_section_depth($format->get_section(2)));
        $this->assertEquals(2, $format->get_section_depth($format->get_section(3)));
        $this->assertEquals(0, $format->find_collapsed_parent(3));
        $this->assertNotEmpty($format->get_view_url(3));
    }

    /**
     * Duplicating a section copies the files in the summary and skips the activities that are being deleted.
     */
    public function test_duplicate_section_files_and_deleted_activities(): void {
        global $DB, $CFG;
        if ((int)$CFG->branch < 402) {
            $this->markTestSkipped('Duplicating sections is only available in Moodle 4.2 and above');
        }
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(
            ['numsections' => 1, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        /** @var \format_flexsections $format */
        $format = course_get_format($course);
        $section = $format->get_section(1);
        $context = context_course::instance($course->id);
        get_file_storage()->create_file_from_string([
            'contextid' => $context->id,
            'component' => 'course',
            'filearea' => 'section',
            'itemid' => $section->id,
            'filepath' => '/',
            'filename' => 'image.png',
        ], 'Image content');
        $generator->create_module('page', ['course' => $course->id, 'section' => 1, 'name' => 'Page 1']);
        $page2 = $generator->create_module('page', ['course' => $course->id, 'section' => 1, 'name' => 'Page 2']);
        $DB->set_field('course_modules', 'deletioninprogress', 1, ['id' => $page2->cmid]);
        rebuild_course_cache($course->id, true);

        $format = course_get_format($course);
        $newsection = $format->duplicate_section($format->get_section(1));

        $files = get_file_storage()->get_area_files($context->id, 'course', 'section', $newsection->id, 'filename', false);
        $this->assertEquals(['image.png'], array_values(array_map(fn($f) => $f->get_filename(), $files)));
        $modinfo = get_fast_modinfo($course->id);
        $this->assertEquals(
            ['Page 1'],
            array_map(fn($cmid) => $modinfo->get_cm($cmid)->name, $modinfo->sections[$newsection->section])
        );
    }

    /**
     * Deleting a course removes all parts of the long section preferences.
     */
    public function test_delete_format_data(): void {
        global $DB;
        $this->resetAfterTest(true);

        $generator = $this->getDataGenerator();
        $course1 = $generator->create_course(['format' => 'flexsections']);
        $course2 = $generator->create_course(['format' => 'flexsections']);
        $user = $generator->create_user();
        $this->setUser($user);
        $value = str_repeat('x', 3000);
        \format_flexsections::set_long_preference('coursesectionspreferences_' . $course1->id, $value);
        \format_flexsections::set_long_preference('coursesectionspreferences_' . $course2->id, $value);
        $this->assertEquals(6, $DB->count_records('user_preferences', ['userid' => $user->id]));

        delete_course($course1, false);

        $names = $DB->get_fieldset_select('user_preferences', 'name', 'userid = ?', [$user->id]);
        sort($names);
        $prefix = 'coursesectionspreferences_' . $course2->id;
        $this->assertEquals([$prefix, $prefix . '#1', $prefix . '#2'], $names);
    }

    /**
     * Names of the course sections (except for section 0) ordered by section number
     *
     * @param int $courseid
     * @return string[]
     */
    protected function get_section_names(int $courseid): array {
        global $DB;
        $sections = $DB->get_records('course_sections', ['course' => $courseid], 'section', 'id, section, name');
        // Make sure there are no gaps in the section numbers.
        $this->assertEquals(range(0, count($sections) - 1), array_map('intval', array_column($sections, 'section')));
        return array_slice(array_column($sections, 'name'), 1);
    }

    /**
     * Test that hiding a section via stateactions also hides subsections recursively.
     *
     * Regression test for https://github.com/marinaglancy/moodle-format_flexsections/issues/107
     * When a section containing subsections is hidden using the AJAX action (section_hide),
     * activities in subsections must also become hidden from students.
     */
    public function test_section_hide_recursive(): void {
        global $DB;
        $this->resetAfterTest(true);

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(
            ['numsections' => 3, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $user = $generator->create_user();
        $teacherrole = $DB->get_record('role', ['shortname' => 'editingteacher']);
        $generator->enrol_user($user->id, $course->id, $teacherrole->id);
        $this->setUser($user);

        /** @var \format_flexsections $format */
        $format = course_get_format($course);

        // Create subsection under section 1, and sub-subsection under that.
        $subsectionnum = $format->create_new_section(1);
        $subsubsectionnum = $format->create_new_section($subsectionnum);

        // Add activities to each level.
        $generator->create_module('assign', ['course' => $course->id, 'section' => 1]);
        $generator->create_module('forum', ['course' => $course->id, 'section' => $subsectionnum]);
        $generator->create_module('page', ['course' => $course->id, 'section' => $subsubsectionnum]);

        // Get section info.
        $modinfo = get_fast_modinfo($course);
        $section1 = $modinfo->get_section_info(1);
        $subsection = $modinfo->get_section_info($subsectionnum);
        $subsubsection = $modinfo->get_section_info($subsubsectionnum);

        // Verify parent hierarchy is correct.
        $this->assertEquals(1, $subsection->parent, 'Subsection parent should be section 1');
        $this->assertEquals($subsectionnum, $subsubsection->parent, 'Sub-subsection parent should be subsection');

        // Verify all sections are visible initially.
        $this->assertEquals(1, $section1->visible);
        $this->assertEquals(1, $subsection->visible);
        $this->assertEquals(1, $subsubsection->visible);

        // Hide section 1 via stateactions (simulating the AJAX hide action).
        $updates = new \core_courseformat\stateupdates($format);
        $actions = new \format_flexsections\courseformat\stateactions();
        $actions->section_hide($updates, $course, [$section1->id]);

        // Verify that section 1 and all its subsections are now hidden.
        $modinfo = get_fast_modinfo($course);
        $this->assertEquals(0, $modinfo->get_section_info(1)->visible, 'Section 1 should be hidden');
        $this->assertEquals(0, $modinfo->get_section_info($subsectionnum)->visible, 'Subsection should be hidden');
        $this->assertEquals(0, $modinfo->get_section_info($subsubsectionnum)->visible, 'Sub-subsection should be hidden');

        // Now show section 1 and verify subsections become visible again.
        $updates = new \core_courseformat\stateupdates($format);
        $actions = new \format_flexsections\courseformat\stateactions();
        $actions->section_show($updates, $course, [$section1->id]);

        $modinfo = get_fast_modinfo($course);
        $this->assertEquals(1, $modinfo->get_section_info(1)->visible, 'Section 1 should be visible');
        $this->assertEquals(1, $modinfo->get_section_info($subsectionnum)->visible, 'Subsection should be visible');
        $this->assertEquals(1, $modinfo->get_section_info($subsubsectionnum)->visible, 'Sub-subsection should be visible');
    }

    /**
     * Hiding a section that does not exist (i.e. was deleted by another user) must not change any sections.
     */
    public function test_section_hide_missing_section(): void {
        global $DB;
        $this->resetAfterTest(true);
        $this->setAdminUser();

        $generator = $this->getDataGenerator();
        $course = $generator->create_course(
            ['numsections' => 3, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        $othercourse = $generator->create_course(
            ['numsections' => 3, 'format' => 'flexsections'],
            ['createsections' => true]
        );
        /** @var \format_flexsections $format */
        $format = course_get_format($course);
        $format->create_new_section(1);
        $deletedsectionid = $format->get_section(3)->id;
        $format->delete_section_with_children($format->get_section(3));
        $othersectionid = course_get_format($othercourse)->get_section(1)->id;

        $format = course_get_format($course);
        foreach ([$deletedsectionid, $othersectionid] as $sectionid) {
            try {
                $updates = new \core_courseformat\stateupdates($format);
                (new \format_flexsections\courseformat\stateactions())->section_hide($updates, $course, [$sectionid]);
                $this->fail('Exception expected');
            } catch (moodle_exception $e) {
                // Expected, the section does not exist in this course.
                $this->assertNotEmpty($e->errorcode);
            }
        }

        $this->assertEquals(0, $DB->count_records('course_sections', ['course' => $course->id, 'visible' => 0]));
        $this->assertEquals(0, $DB->count_records('course_sections', ['course' => $othercourse->id, 'visible' => 0]));
    }
}
