/* eslint-disable camelcase */
// Javascript functions for the FlexTiles course format.

M.course = M.course || {};

M.course.format = M.course.format || {};

/**
 * Get sections config for this format.
 *
 * The tile grid still uses ul/li elements so core and Flexsections
 * drag and drop code can find the section list.
 *
 * @return {object} section list configuration
 */
M.course.format.get_config = function() {
    return {
        container_node: 'ul',
        container_class: 'flextiles-grid',
        section_node: 'li',
        section_class: 'section'
    };
};
