<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Move a FlexTiles section one position up or down among its siblings.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../../config.php');

global $DB;

$courseid = required_param('courseid', PARAM_INT);
$sectionid = required_param('id', PARAM_INT);
$direction = required_param('direction', PARAM_ALPHA);

$course = get_course($courseid);
require_login($course, false);

$context = context_course::instance($courseid);
require_capability('moodle/course:update', $context);
require_capability('moodle/course:movesections', $context);
require_sesskey();

if ($course->format !== 'flextiles') {
    throw new moodle_exception('invalidcourseformat', 'format_flextiles');
}

if (!in_array($direction, ['up', 'down'], true)) {
    throw new moodle_exception('invalidparameter');
}

$section = $DB->get_record('course_sections', [
    'id' => $sectionid,
    'course' => $courseid,
], '*', MUST_EXIST);

/** @var format_flextiles $format */
$format = course_get_format($course);
$sectioninfo = $format->get_section((int)$section->section, MUST_EXIST);
$parentnum = (int)$sectioninfo->parent;
$parent = $format->get_section($parentnum, MUST_EXIST);

$siblings = [];
foreach ($format->get_sections() as $sibling) {
    if ($sibling->section && (int)$sibling->parent === $parentnum) {
        $siblings[(int)$sibling->section] = $sibling;
    }
}
ksort($siblings);

$numbers = array_keys($siblings);
$index = array_search((int)$sectioninfo->section, $numbers, true);
$newsectionnum = (int)$sectioninfo->section;

if ($index !== false && $direction === 'up' && $index > 0) {
    $before = $siblings[$numbers[$index - 1]];
    $newsectionnum = $format->move_section($sectioninfo, $parent, $before);
} else if ($index !== false && $direction === 'down' && $index < count($numbers) - 1) {
    $before = isset($numbers[$index + 2]) ? $siblings[$numbers[$index + 2]] : null;
    $newsectionnum = $format->move_section($sectioninfo, $parent, $before);
}

rebuild_course_cache($courseid, true);

if ($parentnum) {
    $parentinfo = $format->get_section($parentnum);
    if ($parentinfo) {
        $url = new moodle_url('/course/section.php', ['id' => $parentinfo->id], 'section-' . $newsectionnum);
        redirect($url);
    }
}

redirect(new moodle_url('/course/view.php', ['id' => $courseid], 'section-' . $newsectionnum));
