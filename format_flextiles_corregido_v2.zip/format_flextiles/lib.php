<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main class for the FlexTiles course format.
 *
 * FlexTiles keeps the Flexible sections hierarchy (sections with parent,
 * unlimited nesting, indentation and the same editing actions) and changes
 * only the presentation: every child section is shown as a tile.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/format/flexsections/lib.php');

/**
 * FlexTiles course format.
 */
class format_flextiles extends format_flexsections {

    /**
     * FlexTiles never uses the accordion behaviour of Flexsections.
     *
     * @return bool
     */
    public function get_accordion_setting(): bool {
        return false;
    }

    /**
     * FlexTiles always uses the section hierarchy.
     *
     * @return bool
     */
    public function uses_indentation(): bool {
        return true;
    }

    /**
     * Returns the display name of a section.
     *
     * @param int|stdClass|section_info $section
     * @return string
     */
    public function get_default_section_name($section) {
        if (!is_object($section)) {
            $section = $this->get_section($section);
        }
        if ($section->section == 0) {
            return get_string('section0name', 'format_flextiles');
        }
        return parent::get_default_section_name($section);
    }

    /**
     * Number of columns used by the tile grid.
     *
     * @return int
     */
    public function get_tile_columns(): int {
        $columns = (int)($this->get_course()->tilecolumns ?? 3);
        return in_array($columns, [2, 3, 4], true) ? $columns : 3;
    }

    /**
     * Maximum width of the course content.
     *
     * @return string standard|wide|full
     */
    public function get_content_width(): string {
        $width = (string)($this->get_course()->contentwidth ?? 'wide');
        return in_array($width, ['standard', 'wide', 'full'], true) ? $width : 'wide';
    }

    /**
     * Add a body class so the stylesheet can widen the course area.
     *
     * @param \moodle_page $page
     * @return void
     */
    public function page_set_course(\moodle_page $page) {
        global $PAGE;

        parent::page_set_course($page);

        if ($PAGE !== $page) {
            return;
        }

        $width = $this->get_content_width();
        if ($width !== 'standard') {
            $page->add_body_class('flextiles-content-' . $width);
        }
    }

    /**
     * Whether the number of child items is displayed on a tile.
     *
     * @return bool
     */
    public function show_tile_meta(): bool {
        return (bool)($this->get_course()->showtilemeta ?? 1);
    }

    /**
     * Whether the section summary is displayed on a tile.
     *
     * @return bool
     */
    public function show_tile_summary(): bool {
        return (bool)($this->get_course()->showtilesummary ?? 1);
    }

    /**
     * Available Font Awesome icons for section tiles.
     *
     * @return array
     */
    public function get_tile_icon_options(): array {
        return [
            'fa-folder' => get_string('icon_folder', 'format_flextiles'),
            'fa-book' => get_string('icon_book', 'format_flextiles'),
            'fa-graduation-cap' => get_string('icon_graduation', 'format_flextiles'),
            'fa-flask' => get_string('icon_flask', 'format_flextiles'),
            'fa-calculator' => get_string('icon_calculator', 'format_flextiles'),
            'fa-globe' => get_string('icon_globe', 'format_flextiles'),
            'fa-pencil' => get_string('icon_pencil', 'format_flextiles'),
            'fa-code' => get_string('icon_code', 'format_flextiles'),
            'fa-play-circle' => get_string('icon_play', 'format_flextiles'),
            'fa-lightbulb-o' => get_string('icon_lightbulb', 'format_flextiles'),
            'fa-star' => get_string('icon_star', 'format_flextiles'),
            'fa-atom' => get_string('icon_atom', 'format_flextiles'),
        ];
    }

    /**
     * Available accent colours for section tiles.
     *
     * @return array
     */
    public function get_tile_colour_options(): array {
        return [
            1 => get_string('colour_blue', 'format_flextiles'),
            2 => get_string('colour_green', 'format_flextiles'),
            3 => get_string('colour_orange', 'format_flextiles'),
            4 => get_string('colour_purple', 'format_flextiles'),
            5 => get_string('colour_teal', 'format_flextiles'),
            6 => get_string('colour_red', 'format_flextiles'),
        ];
    }

    /**
     * Section format options.
     *
     * @param bool $foreditform
     * @return array
     */
    public function section_format_options($foreditform = false): array {
        $options = parent::section_format_options($foreditform);

        // Keep the hierarchy text in this plugin's language.
        $options['collapsed']['label'] = get_string('displaycontent', 'format_flextiles');
        $options['collapsed']['element_attributes'] = [[
            FORMAT_FLEXSECTIONS_EXPANDED => new lang_string('showexpanded', 'format_flextiles'),
            FORMAT_FLEXSECTIONS_COLLAPSED => new lang_string('showcollapsed', 'format_flextiles'),
        ]];

        // How a child section is displayed inside its parent section.
        $options['displaymode'] = [
            'type' => PARAM_ALPHAEXT,
            'label' => get_string('displaymode', 'format_flextiles'),
            'help' => 'displaymode',
            'help_component' => 'format_flextiles',
            'element_type' => 'select',
            'element_attributes' => [[
                'mosaic' => new lang_string('displaymode_mosaic', 'format_flextiles'),
                'accordion' => new lang_string('displaymode_accordion', 'format_flextiles'),
            ]],
            'default' => 'mosaic',
            'cache' => true,
            'cachedefault' => 'mosaic',
        ];

        $options['tileicon'] = [
            'type' => PARAM_ALPHANUMEXT,
            'label' => get_string('tileicon', 'format_flextiles'),
            'help' => 'tileicon',
            'help_component' => 'format_flextiles',
            'element_type' => 'select',
            'element_attributes' => [$this->get_tile_icon_options()],
            'default' => 'fa-folder',
            'cache' => true,
            'cachedefault' => 'fa-folder',
        ];
        $options['tilecolor'] = [
            'type' => PARAM_INT,
            'label' => get_string('tilecolor', 'format_flextiles'),
            'help' => 'tilecolor',
            'help_component' => 'format_flextiles',
            'element_type' => 'select',
            'element_attributes' => [$this->get_tile_colour_options()],
            'default' => 1,
            'cache' => true,
            'cachedefault' => 1,
        ];
        $options['tileimage'] = [
            'type' => PARAM_URL,
            'label' => get_string('tileimage', 'format_flextiles'),
            'help' => 'tileimage',
            'help_component' => 'format_flextiles',
            'element_type' => 'text',
            'default' => '',
        ];

        return $options;
    }

    /**
     * Create a section and apply FlexTiles defaults.
     *
     * @param int|section_info $parent
     * @param int|null $before
     * @return int
     */
    public function create_new_section($parent = 0, $before = null): int {
        global $DB;

        $sectionnum = parent::create_new_section($parent, $before);
        $section = $DB->get_record('course_sections', [
            'course' => $this->courseid,
            'section' => $sectionnum,
        ]);
        if ($section) {
            $this->update_section_format_options([
                'id' => $section->id,
                'displaymode' => 'mosaic',
            ]);
        }
        return $sectionnum;
    }

    /**
     * Update section options and keep the Flexsections collapsed flag in sync.
     *
     * Top-level sections are always tiles. Subsections are tiles in mosaic
     * mode and expanded inline sections in accordion mode.
     *
     * @param array|stdClass $data
     * @return bool
     */
    public function update_section_format_options($data) {
        global $DB;

        $data = (array)$data;

        if (!empty($data['id'])) {
            // $data['id'] is the course_sections.id, not the section number.
            $section = $DB->get_record('course_sections', ['id' => (int)$data['id']]);
            if ($section) {
                $parent = array_key_exists('parent', $data)
                    ? (int)$data['parent']
                    : (int)$this->get_section_option($section->id, 'parent', 0);

                if ((int)$section->section === 0) {
                    $collapsed = FORMAT_FLEXSECTIONS_EXPANDED;
                } else if ($parent === 0) {
                    $collapsed = FORMAT_FLEXSECTIONS_COLLAPSED;
                } else {
                    $displaymode = (string)($data['displaymode']
                        ?? $this->get_section_option($section->id, 'displaymode', 'mosaic'));
                    $collapsed = ($displaymode === 'accordion')
                        ? FORMAT_FLEXSECTIONS_EXPANDED
                        : FORMAT_FLEXSECTIONS_COLLAPSED;
                }

                $data['collapsed'] = $collapsed;
            }
        }

        $result = parent::update_section_format_options($data);

        if (!empty($data['id'])) {
            $this->sync_options_backup((int)$data['id']);
        }

        return $result;
    }

    /**
     * Migrate Flexsections options when a course is converted to FlexTiles.
     *
     * Moodle deletes all options of the previous format after this method
     * runs, so the hierarchy (parent), visibility and other Flexsections
     * settings must be copied first.
     *
     * @param array|stdClass $data
     * @param stdClass|null $oldcourse
     * @return bool
     */
    public function update_course_format_options($data, $oldcourse = null) {
        $ischangedformat = $oldcourse
            && (int)$oldcourse->id === (int)$this->courseid
            && (string)$oldcourse->format !== 'flextiles';

        if ($ischangedformat) {
            if ((string)$oldcourse->format === 'flexsections') {
                $this->migrate_from_flexsections();
            }

            // Restore the last known FlexTiles options. When coming from
            // Flexsections this only fills options that format does not have,
            // because the fresh Flexsections hierarchy always wins.
            $this->restore_options_backup();
        }

        $result = parent::update_course_format_options($data, $oldcourse);
        $this->normalise_collapsed_options();
        $this->sync_options_backup();

        if ($ischangedformat) {
            rebuild_course_cache($this->courseid, true);
        }

        return $result;
    }

    /**
     * Copy current Flexsections options into the FlexTiles options table.
     *
     * @return void
     */
    protected function migrate_from_flexsections(): void {
        global $DB;

        $rows = $DB->get_records('course_format_options', [
            'courseid' => $this->courseid,
            'format' => 'flexsections',
        ]);
        foreach ($rows as $row) {
            $params = [
                'courseid' => $this->courseid,
                'format' => 'flextiles',
                'sectionid' => $row->sectionid,
                'name' => $row->name,
            ];
            if (!$DB->record_exists('course_format_options', $params)) {
                $DB->insert_record('course_format_options', (object)[
                    'courseid' => $this->courseid,
                    'format' => 'flextiles',
                    'sectionid' => $row->sectionid,
                    'name' => $row->name,
                    'value' => $row->value,
                ]);
            }
        }
    }

    /**
     * Store a copy of the live FlexTiles options in a format-independent table.
     *
     * The "parent" value is stored as a section id instead of a section number,
     * so it can be restored correctly if Moodle renumbers the sections while
     * the course uses another format.
     *
     * @param int|null $sectionid
     * @return void
     */
    protected function sync_options_backup(?int $sectionid = null): void {
        global $DB;

        if (!$DB->get_manager()->table_exists('format_flextiles_options')) {
            return;
        }

        $params = [
            'courseid' => $this->courseid,
            'format' => 'flextiles',
        ];
        if ($sectionid !== null) {
            $params['sectionid'] = $sectionid;
        }

        $options = $DB->get_records('course_format_options', $params, '', 'id,sectionid,name,value');
        $sections = $DB->get_records('course_sections', ['course' => $this->courseid], 'section', 'id,section');
        $sectionids = [];
        foreach ($sections as $section) {
            $sectionids[(int)$section->section] = (int)$section->id;
        }

        $now = time();
        foreach ($options as $option) {
            $value = $option->value;
            if ($option->name === 'parent' && (int)$option->sectionid > 0) {
                $parentnum = (int)$value;
                $value = ($parentnum && isset($sectionids[$parentnum])) ? $sectionids[$parentnum] : 0;
            }

            $backupparams = [
                'courseid' => $this->courseid,
                'sectionid' => $option->sectionid,
                'name' => $option->name,
            ];
            $existing = $DB->get_record('format_flextiles_options', $backupparams, 'id,value');
            if ($existing) {
                if ((string)$existing->value !== (string)$value) {
                    $DB->update_record('format_flextiles_options', (object)[
                        'id' => $existing->id,
                        'value' => $value,
                        'timemodified' => $now,
                    ]);
                }
            } else {
                $DB->insert_record('format_flextiles_options', (object)[
                    'courseid' => $this->courseid,
                    'sectionid' => $option->sectionid,
                    'name' => $option->name,
                    'value' => $value,
                    'timemodified' => $now,
                ]);
            }
        }
    }

    /**
     * Restore missing FlexTiles options from the format-independent table.
     *
     * Existing options are never overwritten: when converting from
     * Flexsections the current hierarchy has priority.
     *
     * @return void
     */
    protected function restore_options_backup(): void {
        global $DB;

        if (!$DB->get_manager()->table_exists('format_flextiles_options')) {
            return;
        }

        $backup = $DB->get_records('format_flextiles_options', ['courseid' => $this->courseid]);
        if (!$backup) {
            return;
        }

        $sections = $DB->get_records('course_sections', ['course' => $this->courseid], 'section', 'id,section');
        $sectionsbyid = [];
        foreach ($sections as $section) {
            $sectionsbyid[(int)$section->id] = $section;
        }

        foreach ($backup as $option) {
            $sectionid = (int)$option->sectionid;
            if ($sectionid > 0 && !isset($sectionsbyid[$sectionid])) {
                continue;
            }

            $value = $option->value;
            if ($option->name === 'parent' && $sectionid > 0) {
                $parentid = (int)$value;
                $parent = $sectionsbyid[$parentid] ?? null;
                $section = $sectionsbyid[$sectionid];
                $value = ($parent && (int)$parent->section < (int)$section->section)
                    ? (int)$parent->section
                    : 0;
            }

            $params = [
                'courseid' => $this->courseid,
                'format' => 'flextiles',
                'sectionid' => $sectionid,
                'name' => $option->name,
            ];
            if (!$DB->record_exists('course_format_options', $params)) {
                $DB->insert_record('course_format_options', (object)[
                    'courseid' => $this->courseid,
                    'format' => 'flextiles',
                    'sectionid' => $sectionid,
                    'name' => $option->name,
                    'value' => $value,
                ]);
            }
        }
    }

    /**
     * Normalise the internal collapsed flag from the hierarchy and display mode.
     *
     * @return void
     */
    protected function normalise_collapsed_options(): void {
        global $DB;

        $sections = $DB->get_records('course_sections', ['course' => $this->courseid], 'section', 'id,section');
        $parents = [];
        $modes = [];
        $options = $DB->get_records('course_format_options', [
            'courseid' => $this->courseid,
            'format' => 'flextiles',
        ], '', 'id,sectionid,name,value');
        foreach ($options as $option) {
            if ($option->name === 'parent') {
                $parents[$option->sectionid] = (int)$option->value;
            } else if ($option->name === 'displaymode') {
                $modes[$option->sectionid] = (string)$option->value;
            }
        }

        foreach ($sections as $section) {
            if ((int)$section->section === 0) {
                $collapsed = FORMAT_FLEXSECTIONS_EXPANDED;
            } else if (empty($parents[$section->id])) {
                $collapsed = FORMAT_FLEXSECTIONS_COLLAPSED;
            } else {
                $collapsed = (($modes[$section->id] ?? 'mosaic') === 'accordion')
                    ? FORMAT_FLEXSECTIONS_EXPANDED
                    : FORMAT_FLEXSECTIONS_COLLAPSED;
            }

            $existing = $DB->get_record('course_format_options', [
                'courseid' => $this->courseid,
                'format' => 'flextiles',
                'sectionid' => $section->id,
                'name' => 'collapsed',
            ]);
            if ($existing) {
                if ((int)$existing->value !== $collapsed) {
                    $existing->value = $collapsed;
                    $DB->update_record('course_format_options', $existing);
                }
            } else {
                $DB->insert_record('course_format_options', (object)[
                    'courseid' => $this->courseid,
                    'format' => 'flextiles',
                    'sectionid' => $section->id,
                    'name' => 'collapsed',
                    'value' => $collapsed,
                ]);
            }
        }
    }

    /**
     * Read one stored section option without loading modinfo.
     *
     * @param int $sectionid
     * @param string $name
     * @param mixed $default
     * @return mixed
     */
    protected function get_section_option(int $sectionid, string $name, $default = null) {
        global $DB;

        $value = $DB->get_field('course_format_options', 'value', [
            'courseid' => $this->courseid,
            'format' => 'flextiles',
            'sectionid' => $sectionid,
            'name' => $name,
        ]);

        return $value === false ? $default : $value;
    }

    /**
     * Return the section edit form.
     *
     * @param mixed $action
     * @param array $customdata
     * @return \moodleform
     */
    public function editsection_form($action, $customdata = []) {
        global $CFG;

        require_once($CFG->dirroot . '/course/editsection_form.php');
        require_once(__DIR__ . '/classes/form/editsection_form.php');

        if (!array_key_exists('course', $customdata)) {
            $customdata['course'] = $this->get_course();
        }

        return new \format_flextiles\form\editsection_form($action, $customdata);
    }

    /**
     * Course format options.
     *
     * @param bool $foreditform
     * @return array
     */
    public function course_format_options($foreditform = false) {
        $options = parent::course_format_options($foreditform);

        // FlexTiles has no accordion. Remove the option so teachers are not confused.
        unset($options['accordion']);

        $options['tilecolumns'] = [
            'default' => 3,
            'type' => PARAM_INT,
        ];
        $options['showtilemeta'] = [
            'default' => 1,
            'type' => PARAM_BOOL,
        ];
        $options['showtilesummary'] = [
            'default' => 1,
            'type' => PARAM_BOOL,
        ];
        $options['contentwidth'] = [
            'default' => 'wide',
            'type' => PARAM_ALPHA,
        ];

        if ($foreditform) {
            // Use this plugin's strings for options inherited from Flexsections.
            $options['showsection0title']['label'] = new lang_string('showsection0title', 'format_flextiles');
            $options['showsection0title']['help'] = 'showsection0title';
            $options['showsection0title']['help_component'] = 'format_flextiles';
            $options['courseindexdisplay']['label'] = new lang_string('courseindexdisplay', 'format_flextiles');
            $options['courseindexdisplay']['element_attributes'] = [[
                \format_flexsections\constants::COURSEINDEX_FULL => new lang_string('courseindexfull', 'format_flextiles'),
                \format_flexsections\constants::COURSEINDEX_SECTIONS => new lang_string('courseindexsections', 'format_flextiles'),
                \format_flexsections\constants::COURSEINDEX_NONE => new lang_string('courseindexnone', 'format_flextiles'),
            ]];
            $options['cmbacklink']['label'] = new lang_string('cmbacklink', 'format_flextiles');
            $options['cmbacklink']['help'] = 'cmbacklink';
            $options['cmbacklink']['help_component'] = 'format_flextiles';

            $options['tilecolumns']['label'] = new lang_string('tilecolumns', 'format_flextiles');
            $options['tilecolumns']['help'] = 'tilecolumns';
            $options['tilecolumns']['help_component'] = 'format_flextiles';
            $options['tilecolumns']['element_type'] = 'select';
            $options['tilecolumns']['element_attributes'] = [[
                2 => new lang_string('columns2', 'format_flextiles'),
                3 => new lang_string('columns3', 'format_flextiles'),
                4 => new lang_string('columns4', 'format_flextiles'),
            ]];
            $options['showtilemeta']['label'] = new lang_string('showtilemeta', 'format_flextiles');
            $options['showtilemeta']['help'] = 'showtilemeta';
            $options['showtilemeta']['help_component'] = 'format_flextiles';
            $options['showtilemeta']['element_type'] = 'advcheckbox';
            $options['showtilesummary']['label'] = new lang_string('showtilesummary', 'format_flextiles');
            $options['showtilesummary']['help'] = 'showtilesummary';
            $options['showtilesummary']['help_component'] = 'format_flextiles';
            $options['showtilesummary']['element_type'] = 'advcheckbox';
            $options['contentwidth']['label'] = new lang_string('contentwidth', 'format_flextiles');
            $options['contentwidth']['help'] = 'contentwidth';
            $options['contentwidth']['help_component'] = 'format_flextiles';
            $options['contentwidth']['element_type'] = 'select';
            $options['contentwidth']['element_attributes'] = [[
                'standard' => new lang_string('contentwidth_standard', 'format_flextiles'),
                'wide' => new lang_string('contentwidth_wide', 'format_flextiles'),
                'full' => new lang_string('contentwidth_full', 'format_flextiles'),
            ]];
        }

        return $options;
    }
}

/**
 * Returns the current activity when a "back to section" link must be displayed.
 *
 * This is a FlexTiles equivalent of format_flexsections_add_back_link_to_cm().
 *
 * @return cm_info|null
 */
function format_flextiles_add_back_link_to_cm(): ?cm_info {
    global $PAGE, $CFG;

    if (
        $PAGE->course
            && $PAGE->cm
            && $PAGE->course->format === 'flextiles'
            && course_get_format($PAGE->course)->get_course()->cmbacklink
            && $PAGE->pagelayout === 'incourse'
            && $PAGE->cm->sectionnum
            && $PAGE->url
            && $PAGE->url->out_omit_querystring() === $CFG->wwwroot . "/mod/{$PAGE->cm->modname}/view.php"
    ) {
        return $PAGE->cm;
    }
    return null;
}
