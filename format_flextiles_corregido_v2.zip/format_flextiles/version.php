<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026102324;              // The current plugin version.
$plugin->requires  = 2024100100;              // Requires Moodle 4.5 or above.
$plugin->release   = '0.4.4';
$plugin->maturity  = MATURITY_BETA;
$plugin->component = 'format_flextiles';
$plugin->supported = [405, 405];

// FlexTiles reuses the Flexible sections hierarchy, editing and backup code.
$plugin->dependencies = [
    'format_flexsections' => 2024120804,
];
