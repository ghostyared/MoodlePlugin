<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for format_flextiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the plugin.
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_format_flextiles_upgrade($oldversion) {
    global $DB;

    if ($oldversion < 2026102203) {
        $courses = $DB->get_records('course', ['format' => 'flextiles']);
        foreach ($courses as $course) {
            $sections = $DB->get_records('course_sections', ['course' => $course->id], 'section', 'id,section');

            // Read the hierarchy and display mode directly from the options table.
            // Calling the format classes here would use get_fast_modinfo(), which
            // is not allowed while Moodle is still upgrading.
            $parents = [];
            $modes = [];
            $options = $DB->get_records(
                'course_format_options',
                ['courseid' => $course->id, 'format' => 'flextiles'],
                '',
                'id,sectionid,name,value'
            );
            foreach ($options as $option) {
                if ($option->name === 'parent') {
                    $parents[$option->sectionid] = (int)$option->value;
                } else if ($option->name === 'displaymode') {
                    $modes[$option->sectionid] = (string)$option->value;
                }
            }

            foreach ($sections as $section) {
                if ((int)$section->section === 0) {
                    $collapsed = 0;
                } else if (empty($parents[$section->id])) {
                    $collapsed = 1;
                } else {
                    $collapsed = (($modes[$section->id] ?? 'mosaic') === 'accordion') ? 0 : 1;
                }

                $existing = $DB->get_record('course_format_options', [
                    'courseid' => $course->id,
                    'format' => 'flextiles',
                    'sectionid' => $section->id,
                    'name' => 'collapsed',
                ]);
                if ($existing) {
                    if ((int)$existing->value !== $collapsed) {
                        $existing->value = $collapsed;
                        $DB->update_record('course_format_options', $existing);
                    }
                } else {
                    $DB->insert_record('course_format_options', (object)[
                        'courseid' => $course->id,
                        'format' => 'flextiles',
                        'sectionid' => $section->id,
                        'name' => 'collapsed',
                        'value' => $collapsed,
                    ]);
                }
            }
        }

        upgrade_plugin_savepoint(true, 2026102203, 'format', 'flextiles');
    }

    if ($oldversion < 2026102211) {
        // New course option: content width (standard, wide or full). The default is
        // resolved by course_format_options(), so no schema change is needed.
        upgrade_plugin_savepoint(true, 2026102211, 'format', 'flextiles');
    }

    if ($oldversion < 2026102220) {
        // Persistent copy of the FlexTiles options. Moodle deletes the previous
        // format options when a course changes format, so the hierarchy (parent),
        // display mode and tile appearance need their own storage.
        $dbman = $DB->get_manager();
        $table = new xmldb_table('format_flextiles_options');

        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('sectionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('name', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, '');
        $table->add_field('value', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_index('courseid-sectionid-name', XMLDB_INDEX_UNIQUE, ['courseid', 'sectionid', 'name']);
        $table->add_index('courseid', XMLDB_INDEX_NOTUNIQUE, ['courseid']);

        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Populate the backup for courses that already use FlexTiles.
        $courseids = $DB->get_fieldset_sql(
            "SELECT DISTINCT courseid FROM {course_format_options} WHERE format = ?",
            ['flextiles']
        );
        foreach ($courseids as $courseid) {
            $sections = $DB->get_records('course_sections', ['course' => $courseid], 'section', 'id,section');
            $sectionids = [];
            foreach ($sections as $section) {
                $sectionids[(int)$section->section] = (int)$section->id;
            }

            $options = $DB->get_records(
                'course_format_options',
                ['courseid' => $courseid, 'format' => 'flextiles'],
                '',
                'id,sectionid,name,value'
            );
            foreach ($options as $option) {
                $value = $option->value;
                if ($option->name === 'parent' && (int)$option->sectionid > 0) {
                    $parentnum = (int)$value;
                    $value = ($parentnum && isset($sectionids[$parentnum])) ? $sectionids[$parentnum] : 0;
                }

                $params = [
                    'courseid' => $courseid,
                    'sectionid' => $option->sectionid,
                    'name' => $option->name,
                ];
                if (!$DB->record_exists('format_flextiles_options', $params)) {
                    $DB->insert_record('format_flextiles_options', (object)[
                        'courseid' => $courseid,
                        'sectionid' => $option->sectionid,
                        'name' => $option->name,
                        'value' => $value,
                        'timemodified' => time(),
                    ]);
                }
            }
        }

        upgrade_plugin_savepoint(true, 2026102220, 'format', 'flextiles');
    }

    if ($oldversion < 2026102221) {
        // Rebuild the backup for courses that are using FlexTiles right now.
        // Courses that are in another format keep their existing backup.
        $courseids = $DB->get_fieldset_sql(
            "SELECT DISTINCT courseid FROM {course_format_options} WHERE format = ?",
            ['flextiles']
        );
        foreach ($courseids as $courseid) {
            $DB->delete_records('format_flextiles_options', ['courseid' => $courseid]);

            $sections = $DB->get_records('course_sections', ['course' => $courseid], 'section', 'id,section');
            $sectionids = [];
            foreach ($sections as $section) {
                $sectionids[(int)$section->section] = (int)$section->id;
            }

            $options = $DB->get_records(
                'course_format_options',
                ['courseid' => $courseid, 'format' => 'flextiles'],
                '',
                'id,sectionid,name,value'
            );
            foreach ($options as $option) {
                $value = $option->value;
                if ($option->name === 'parent' && (int)$option->sectionid > 0) {
                    $parentnum = (int)$value;
                    $value = ($parentnum && isset($sectionids[$parentnum])) ? $sectionids[$parentnum] : 0;
                }

                $DB->insert_record('format_flextiles_options', (object)[
                    'courseid' => $courseid,
                    'sectionid' => $option->sectionid,
                    'name' => $option->name,
                    'value' => $value,
                    'timemodified' => time(),
                ]);
            }
        }

        upgrade_plugin_savepoint(true, 2026102221, 'format', 'flextiles');
    }

    if ($oldversion < 2026102222) {
        // The move controls ignore the General section when listing top-level
        // siblings. No database change is required.
        upgrade_plugin_savepoint(true, 2026102222, 'format', 'flextiles');
    }

    if ($oldversion < 2026102323) {
        // Visible name changed to Formato-Mariategui. The technical component
        // remains format_flextiles to keep existing courses and backups working.
        upgrade_plugin_savepoint(true, 2026102323, 'format', 'flextiles');
    }

    if ($oldversion < 2026102324) {
        // Section header cleanup: no kicker and no visible summary block.
        // Activities stay in the new flextiles-section-content wrapper.
        upgrade_plugin_savepoint(true, 2026102324, 'format', 'flextiles');
    }

    return true;
}
