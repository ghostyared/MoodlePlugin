<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Section edit form for FlexTiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_flextiles\form;

/**
 * Section edit form.
 *
 * The parent class adds all format options. FlexTiles hides the internal
 * collapsed option and only shows the mosaic/accordion selector on
 * subsections, never on top-level sections.
 */
class editsection_form extends \editsection_form {

    /**
     * Form definition.
     */
    public function definition() {
        parent::definition();

        $section = $this->_customdata['cs'] ?? null;
        if (!$section) {
            return;
        }

        // Collapsed is calculated automatically from the display mode.
        $this->_form->removeElement('collapsed');

        // Top-level sections always use the mosaic grid.
        if (empty($section->parent)) {
            $this->_form->removeElement('displaymode');
        }
    }
}
