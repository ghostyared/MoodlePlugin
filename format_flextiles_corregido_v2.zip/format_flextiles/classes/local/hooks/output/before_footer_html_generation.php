<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Footer hook for FlexTiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_flextiles\local\hooks\output;

/**
 * Adds the "back to section" link on activity pages.
 */
class before_footer_html_generation {
    /**
     * Callback allowing to add content inside the region-main, at the very end.
     *
     * @param \core\hook\output\before_footer_html_generation $hook
     */
    public static function callback(\core\hook\output\before_footer_html_generation $hook): void {
        global $OUTPUT, $CFG;

        if (during_initial_install() || isset($CFG->upgraderunning)) {
            return;
        }

        require_once($CFG->dirroot . '/course/format/flextiles/lib.php');

        if ($cm = format_flextiles_add_back_link_to_cm()) {
            $modinfo = get_fast_modinfo($cm->course);
            $section = $modinfo->get_section_info($cm->sectionnum);
            if (!$section) {
                return;
            }
            $hook->add_html($OUTPUT->render_from_template('format_flextiles/back_link_in_cms', [
                'backtosection' => [
                    'url' => (new \moodle_url('/course/section.php', ['id' => $section->id]))->out(false),
                    'sectionname' => get_section_name($cm->course, $cm->sectionnum),
                ],
            ]));
        }
    }
}
