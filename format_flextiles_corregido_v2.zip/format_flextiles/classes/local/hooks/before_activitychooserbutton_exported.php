<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Activity chooser hook for FlexTiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_flextiles\local\hooks;

/**
 * Remove the subsection activity from the chooser: FlexTiles uses sections
 * themselves for the hierarchy, not the mod_subsection activity.
 */
class before_activitychooserbutton_exported {
    /**
     * This hook is triggered when an activity chooser button is exported.
     *
     * @param \core_course\hook\before_activitychooserbutton_exported $hook
     */
    public static function callback(\core_course\hook\before_activitychooserbutton_exported $hook): void {
        $activitychooserbutton = $hook->get_activitychooserbutton();
        $section = $hook->get_section();
        $format = course_get_format($section->course);

        if ($format->get_format() !== 'flextiles') {
            return;
        }

        // Remove the action link added by mod_subsection.
        $refobject = new \ReflectionObject($activitychooserbutton);
        $refproperty = $refobject->getProperty('actionlinks');
        $refproperty->setAccessible(true);
        $actionlinks = $refproperty->getValue($activitychooserbutton);
        $actionlinks = array_filter($actionlinks, fn($a) => ($a->attributes['data-modname'] ?? null) !== 'subsection');
        $refproperty->setValue($activitychooserbutton, array_values($actionlinks));
    }
}
