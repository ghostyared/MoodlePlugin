<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course content output for FlexTiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_flextiles\output\courseformat;

use context_course;
use moodle_url;
use renderer_base;
use stdClass;

/**
 * Render the complete course content as a drill-down tile grid.
 */
class content extends \format_flexsections\output\courseformat\content {

    /**
     * Template name.
     *
     * @param renderer_base $renderer
     * @return string
     */
    public function get_template_name(renderer_base $renderer): string {
        return 'format_flextiles/local/content';
    }

    /**
     * Export the content context.
     *
     * @param renderer_base $output
     * @return stdClass
     */
    public function export_for_template(renderer_base $output): stdClass {
        $data = parent::export_for_template($output);

        $course = $this->format->get_course();
        $courseid = $this->format->get_courseid();
        $data->flextilesid = 'flextiles-course-' . $courseid;
        $data->tilecolumns = $this->format->get_tile_columns();
        $data->showtilemeta = $this->format->show_tile_meta();
        $data->showtilesummary = $this->format->show_tile_summary();

        // The parent uses Flexsections URLs (anchors or course/view.php).
        // FlexTiles always navigates to a clean single-section page.
        $viewed = $this->format->get_viewed_section();
        if ($viewed) {
            $section = $this->format->get_section($viewed);
            $data->backtocourse = [
                'url' => (new moodle_url('/course/view.php', ['id' => $courseid]))->out(false),
                'coursename' => format_string(
                    $course->fullname,
                    true,
                    ['context' => context_course::instance($courseid)]
                ),
            ];
            if ($section && $section->parent) {
                $parent = $this->format->get_section($section->parent);
                if ($parent) {
                    $data->backtosection = [
                        'url' => (new moodle_url('/course/section.php', ['id' => $parent->id]))->out(false),
                        'sectionname' => $this->format->get_section_name($parent),
                    ];
                }
            } else {
                unset($data->backtosection);
            }
        }

        return $data;
    }
}
