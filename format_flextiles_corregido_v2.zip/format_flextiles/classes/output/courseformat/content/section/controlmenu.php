<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Section actions menu for FlexTiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_flextiles\output\courseformat\content\section;

use context_course;
use moodle_url;

/**
 * Section control menu.
 *
 * Flexsections removes the delete action from the currently viewed section
 * and hides "Add subsection" on sections displayed as links. FlexTiles opens
 * most sections as separate pages, so both restrictions would hide basic
 * actions. This class restores them.
 */
class controlmenu extends \format_flexsections\output\courseformat\content\section\controlmenu {

    /**
     * Generate the edit control items of a section.
     *
     * @return array
     */
    public function section_control_items() {
        $controls = parent::section_control_items();

        $format = $this->format;
        $section = $this->section;
        $course = $format->get_course();
        $coursecontext = context_course::instance($course->id);

        if (
            has_capability('moodle/course:update', $coursecontext) &&
                $section->section &&
                empty($controls['addsubsection']) &&
                $format->get_section_depth($section) < $format->get_max_section_depth()
        ) {
            $sectionreturn = $format->get_section_number();
            $url = $sectionreturn ? course_get_url($course, $section->section) : course_get_url($course);
            $url->param('sesskey', sesskey());
            $addsubsectionurl = new moodle_url($url, ['addchildsection' => $section->section]);
            $controls['addsubsection'] = [
                'url' => $addsubsectionurl,
                'icon' => 't/add',
                'name' => get_string('addsubsection', 'format_flexsections'),
                'pixattr' => ['class' => ''],
                'attr' => [
                    'class' => 'editing_addsubsection',
                    'data-action-flexsections' => 'addSubSection',
                    'data-parentid' => $section->id,
                ],
            ];
        }

        // Restore delete for every section, including the current section page.
        if ($section->section && course_can_delete_section($course, $section)) {
            $deleteurl = new moodle_url('/course/editsection.php', [
                'id' => $section->id,
                'delete' => 1,
                'sesskey' => sesskey(),
            ]);
            $controls['delete'] = [
                'url' => $deleteurl,
                'icon' => 'i/delete',
                'name' => get_string('deletesection'),
                'pixattr' => ['class' => ''],
                'attr' => [
                    'class' => 'icon editing_delete text-danger',
                    'data-action-flexsections' => 'delete',
                    'data-id' => $section->id,
                ],
            ];
        } else if (empty($section->section)) {
            unset($controls['delete']);
        }

        // Quick reordering inside the same parent section. Dragging tiles is
        // not available in FlexTiles, so these links provide a predictable
        // way to move a section before or after its siblings.
        if (
            $section->section &&
                has_all_capabilities(
                    ['moodle/course:update', 'moodle/course:movesections'],
                    $coursecontext
                )
        ) {
            $siblings = [];
            foreach ($format->get_sections() as $sibling) {
                if ($sibling->section && (int)$sibling->parent === (int)$section->parent) {
                    $siblings[(int)$sibling->section] = $sibling;
                }
            }
            ksort($siblings);
            $numbers = array_keys($siblings);
            $index = array_search((int)$section->section, $numbers, true);

            if ($index !== false && $index > 0) {
                $controls['moveup'] = [
                    'url' => new moodle_url('/course/format/flextiles/move.php', [
                        'courseid' => $course->id,
                        'id' => $section->id,
                        'direction' => 'up',
                        'sesskey' => sesskey(),
                    ]),
                    'icon' => 't/up',
                    'name' => get_string('moveup', 'moodle'),
                    'pixattr' => ['class' => ''],
                    'attr' => ['class' => 'editing_moveup'],
                ];
            }

            if ($index !== false && $index < count($numbers) - 1) {
                $controls['movedown'] = [
                    'url' => new moodle_url('/course/format/flextiles/move.php', [
                        'courseid' => $course->id,
                        'id' => $section->id,
                        'direction' => 'down',
                        'sesskey' => sesskey(),
                    ]),
                    'icon' => 't/down',
                    'name' => get_string('movedown', 'moodle'),
                    'pixattr' => ['class' => ''],
                    'attr' => ['class' => 'editing_movedown'],
                ];
            }
        }

        // The display mode controls the internal collapsed flag.
        unset($controls['collapsed']);

        return $controls;
    }
}
