<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Section output for FlexTiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_flextiles\output\courseformat\content;

use moodle_url;
use renderer_base;
use stdClass;

/**
 * Adds tile data to every section and decides whether it is a tile or the
 * current (full) section page.
 */
class section extends \format_flexsections\output\courseformat\content\section {

    /**
     * Template name.
     *
     * @param renderer_base $renderer
     * @return string
     */
    public function get_template_name(renderer_base $renderer): string {
        return 'format_flextiles/local/content/section';
    }

    /**
     * Export the section context.
     *
     * @param renderer_base $output
     * @return stdClass
     */
    public function export_for_template(renderer_base $output): stdClass {
        global $PAGE;

        $data = parent::export_for_template($output);

        // course/view.php?section=... does not add the page header action menu
        // that course/section.php adds, and the core section exporter removes
        // the inline control menu from the current section. Add it back here so
        // editing actions (delete, hide, add subsection) are always available.
        $issectionpage = strpos($PAGE->url->out_omit_querystring(), '/course/section.php') !== false;
        if ($PAGE->user_is_editing() && empty($data->controlmenu) && !$issectionpage) {
            $controlmenu = new $this->controlmenuclass($this->format, $this->section);
            $menu = $controlmenu->export_for_template($output);
            if (!empty($menu->hasmenu)) {
                $data->controlmenu = $menu;
            }
        }

        $options = $this->format->get_format_options($this->section);
        $sectionname = $this->format->get_section_name($this->section);
        $viewed = (int)$this->format->get_viewed_section();

        $tileicon = (string)($options['tileicon'] ?? 'fa-folder');
        if (!preg_match('/^fa-[a-z0-9-]+$/', $tileicon)) {
            $tileicon = 'fa-folder';
        }
        $tilecolor = (int)($options['tilecolor'] ?? 1);
        if ($tilecolor < 1 || $tilecolor > 6) {
            $tilecolor = 1;
        }
        $tileimage = trim((string)($options['tileimage'] ?? ''));
        if ($tileimage !== '' && !preg_match('~^https?://~i', $tileimage)) {
            $tileimage = '';
        }

        $summarytext = '';
        if (!empty($data->summary)) {
            $summary = (array)$data->summary;
            $summarytext = (string)($summary['summarytext'] ?? '');
        }
        if ($summarytext !== '') {
            $summarytext = html_to_text($summarytext, 0, false);
            $summarytext = shorten_text(trim($summarytext), 150);
        }

        $children = $this->format->get_subsections($this->section->section);
        $visiblechildren = 0;
        foreach ($children as $child) {
            if ($this->format->is_section_visible($child)) {
                $visiblechildren++;
            }
        }
        if ($visiblechildren > 0) {
            $tilemeta = get_string('tilethemes', 'format_flextiles', $visiblechildren);
            $tilehaschildren = true;
        } else {
            $cms = $this->format->get_modinfo()->sections[$this->section->section] ?? [];
            $tilemeta = $cms
                ? get_string('tileactivities', 'format_flextiles', count($cms))
                : get_string('tileempty', 'format_flextiles');
            $tilehaschildren = false;
        }

        $displaymode = (string)($options['displaymode'] ?? 'mosaic');
        if (!in_array($displaymode, ['mosaic', 'accordion'], true)) {
            $displaymode = 'mosaic';
        }

        $data->displaymode = $displaymode;
        $data->accordion = $this->section->section != 0
            && $viewed != $this->section->section
            && !empty($this->section->parent)
            && $displaymode === 'accordion';
        $data->tileonly = $this->section->section != 0
            && $viewed != $this->section->section
            && !$data->accordion;
        $data->haschildren = !empty($data->subsections) || !empty($data->insertsubsection);
        $showsection0title = !empty($this->format->get_course()->showsection0title);
        // Keep the section header (and its action menu) on every section page.
        // Hiding it on single-section pages also hid delete, visibility and
        // subsection actions.
        $data->flextileshidesectiontitle = $this->section->section == 0 && !$showsection0title;
        $data->tilesectionname = $sectionname;
        $data->tileicon = $tileicon;
        $data->tilecolor = $tilecolor;
        $data->tileimage = $tileimage;
        $data->tilehasimage = $tileimage !== '';
        $data->tilesummary = $this->format->show_tile_summary() ? $summarytext : '';
        $data->tilemeta = $this->format->show_tile_meta() ? $tilemeta : '';
        $data->tilehaschildren = $tilehaschildren;
        $data->tilecolumns = $this->format->get_tile_columns();
        $data->tileurl = (new moodle_url('/course/section.php', ['id' => $this->section->id]))->out(false);
        $data->tilelinktitle = get_string('opentile', 'format_flextiles', $sectionname);

        return $data;
    }
}
