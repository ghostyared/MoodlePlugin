<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Spanish language strings for format_flextiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Formato-Mariategui';
$string['sectionname'] = 'Tema';
$string['section0name'] = 'General';
$string['section'] = 'Sección';
$string['invalidcourseformat'] = 'Esta acción solo está disponible en un curso con el formato Formato-Mariategui.';

$string['displaycontent'] = 'Mostrar contenido de la sección';
$string['showexpanded'] = 'En la misma página';
$string['showcollapsed'] = 'En una página aparte';

$string['displaymode'] = 'Visualización dentro de la sección superior';
$string['displaymode_help'] = 'Solo se aplica a las subsecciones. En mosaico se muestra una tarjeta que abre la subsección; en acordeón se muestra el contenido dentro de la sección superior.';
$string['displaymode_mosaic'] = 'Mosaico';
$string['displaymode_accordion'] = 'Acordeón';
$string['tilehidden'] = 'Oculta';
$string['tileunavailable'] = 'Con restricciones';
$string['hidefromothers'] = 'Ocultar sección';
$string['showfromothers'] = 'Mostrar sección';

$string['showsection0title'] = 'Mostrar el título de la sección General';
$string['showsection0title_help'] = 'Si se activa, el título de la sección General se muestra encima de sus actividades.';
$string['courseindexdisplay'] = 'Índice del curso';
$string['courseindexfull'] = 'Mostrar el índice completo';
$string['courseindexsections'] = 'Mostrar solo las secciones';
$string['courseindexnone'] = 'No mostrar el índice';
$string['cmbacklink'] = 'Mostrar enlace de regreso a la sección en las actividades';
$string['cmbacklink_help'] = 'Agrega un enlace para volver a la página de la sección cuando se abre una actividad.';

$string['tilecolumns'] = 'Columnas del mosaico';
$string['tilecolumns_help'] = 'Cantidad de columnas en pantallas grandes. El mosaico se adapta automáticamente en pantallas pequeñas.';
$string['columns2'] = '2 columnas';
$string['columns3'] = '3 columnas';
$string['columns4'] = '4 columnas';
$string['showtilemeta'] = 'Mostrar cantidad de elementos en los mosaicos';
$string['showtilemeta_help'] = 'Muestra cuántos temas o contenidos tiene cada mosaico.';
$string['showtilesummary'] = 'Mostrar el resumen de la sección en los mosaicos';
$string['showtilesummary_help'] = 'Muestra un extracto corto del resumen de la sección dentro de cada mosaico.';
$string['contentwidth'] = 'Ancho del contenido';
$string['contentwidth_help'] = 'Ancho máximo del área del curso en pantallas grandes. En móviles y tabletas se mantiene al 100% para conservar el diseño responsive.';
$string['contentwidth_standard'] = 'Estándar (830 px)';
$string['contentwidth_wide'] = 'Amplio (1400 px)';
$string['contentwidth_full'] = 'Ancho completo';

$string['tileicon'] = 'Icono del mosaico';
$string['tileicon_help'] = 'Icono que se muestra en el mosaico cuando no tiene imagen.';
$string['tilecolor'] = 'Color del mosaico';
$string['tilecolor_help'] = 'Color de acento del borde, el icono y los elementos de progreso del mosaico.';
$string['tileimage'] = 'URL de imagen del mosaico';
$string['tileimage_help'] = 'URL pública opcional de una imagen http(s). Si se deja vacío, se usa el icono seleccionado. La imagen no se sube a Moodle.';

$string['icon_folder'] = 'Carpeta';
$string['icon_book'] = 'Libro';
$string['icon_graduation'] = 'Birrete';
$string['icon_flask'] = 'Matraz';
$string['icon_calculator'] = 'Calculadora';
$string['icon_globe'] = 'Globo terráqueo';
$string['icon_pencil'] = 'Lápiz';
$string['icon_code'] = 'Código';
$string['icon_play'] = 'Reproducir';
$string['icon_lightbulb'] = 'Bombilla';
$string['icon_star'] = 'Estrella';
$string['icon_atom'] = 'Átomo';

$string['colour_blue'] = 'Azul';
$string['colour_green'] = 'Verde';
$string['colour_orange'] = 'Naranja';
$string['colour_purple'] = 'Morado';
$string['colour_teal'] = 'Turquesa';
$string['colour_red'] = 'Rojo';

$string['tilethemes'] = 'Temas: {$a}';
$string['tileactivities'] = 'Temas: {$a}';
$string['tileempty'] = 'Sin contenido todavía';
$string['opentile'] = 'Abrir {$a}';
$string['backtosection'] = 'Volver a';
$string['backtocourse'] = 'Volver al curso';
