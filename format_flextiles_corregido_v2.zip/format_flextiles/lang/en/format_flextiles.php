<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for format_flextiles.
 *
 * @package    format_flextiles
 * @copyright  2026 Yared.AI
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Formato-Mariategui';
$string['sectionname'] = 'Theme';
$string['section0name'] = 'General';
$string['section'] = 'Section';
$string['invalidcourseformat'] = 'This action is only available in a course using the Formato-Mariategui format.';

$string['displaycontent'] = 'Display section content';
$string['showexpanded'] = 'On the same page';
$string['showcollapsed'] = 'On a separate page';

$string['displaymode'] = 'Display inside the parent section';
$string['displaymode_help'] = 'Only applies to subsections. Mosaic shows a tile that opens the subsection; accordion shows its content inside the parent section.';
$string['displaymode_mosaic'] = 'Mosaic';
$string['displaymode_accordion'] = 'Accordion';
$string['tilehidden'] = 'Hidden';
$string['tileunavailable'] = 'Restricted';
$string['hidefromothers'] = 'Hide section';
$string['showfromothers'] = 'Show section';

$string['showsection0title'] = 'Show the General section title';
$string['showsection0title_help'] = 'If enabled, the General section title is displayed above its activities.';
$string['courseindexdisplay'] = 'Course index';
$string['courseindexfull'] = 'Show the full course index';
$string['courseindexsections'] = 'Show sections only';
$string['courseindexnone'] = 'Do not show the course index';
$string['cmbacklink'] = 'Show a back-to-section link on activity pages';
$string['cmbacklink_help'] = 'Adds a link back to the section page when an activity is opened.';

$string['tilecolumns'] = 'Tile columns';
$string['tilecolumns_help'] = 'Number of tile columns used on wide screens. The grid adapts automatically on smaller screens.';
$string['columns2'] = '2 columns';
$string['columns3'] = '3 columns';
$string['columns4'] = '4 columns';
$string['showtilemeta'] = 'Show the number of items on tiles';
$string['showtilemeta_help'] = 'Displays how many themes or activities each tile contains.';
$string['showtilesummary'] = 'Show the section summary on tiles';
$string['showtilesummary_help'] = 'Displays a short excerpt of the section summary inside each tile.';
$string['contentwidth'] = 'Content width';
$string['contentwidth_help'] = 'Maximum width of the course area on large screens. On phones and tablets it stays at 100% to keep the responsive layout.';
$string['contentwidth_standard'] = 'Standard (830 px)';
$string['contentwidth_wide'] = 'Wide (1400 px)';
$string['contentwidth_full'] = 'Full width';

$string['tileicon'] = 'Tile icon';
$string['tileicon_help'] = 'Icon displayed on the tile when it has no image.';
$string['tilecolor'] = 'Tile colour';
$string['tilecolor_help'] = 'Accent colour used by the tile border, icon and progress elements.';
$string['tileimage'] = 'Tile image URL';
$string['tileimage_help'] = 'Optional public http(s) image URL. Leave empty to use the selected icon. The image is not uploaded to Moodle.';

$string['icon_folder'] = 'Folder';
$string['icon_book'] = 'Book';
$string['icon_graduation'] = 'Graduation cap';
$string['icon_flask'] = 'Flask';
$string['icon_calculator'] = 'Calculator';
$string['icon_globe'] = 'Globe';
$string['icon_pencil'] = 'Pencil';
$string['icon_code'] = 'Code';
$string['icon_play'] = 'Play';
$string['icon_lightbulb'] = 'Light bulb';
$string['icon_star'] = 'Star';
$string['icon_atom'] = 'Atom';

$string['colour_blue'] = 'Blue';
$string['colour_green'] = 'Green';
$string['colour_orange'] = 'Orange';
$string['colour_purple'] = 'Purple';
$string['colour_teal'] = 'Teal';
$string['colour_red'] = 'Red';

$string['tilethemes'] = 'Themes: {$a}';
$string['tileactivities'] = 'Themes: {$a}';
$string['tileempty'] = 'No content yet';
$string['opentile'] = 'Open {$a}';
$string['backtosection'] = 'Back to';
$string['backtocourse'] = 'Back to the course';
