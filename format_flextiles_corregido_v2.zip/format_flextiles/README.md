# Formato-Mariategui para Moodle 4.5

**Componente técnico:** `format_flextiles` (sin cambios)  
**Versión:** 0.4.4 (`2026102324`)  
**Requiere:** Moodle 4.5 y `format_flexsections` 4.1.7 o superior (`2024120804`).

Formato-Mariategui conserva la jerarquía de secciones de Flexsections (`Section_01 > tema01 > contenido01`) y cambia la presentación: las secciones de primer nivel y las subsecciones en modo mosaico se muestran como tarjetas. Las subsecciones también pueden mostrarse como acordeón dentro de la sección superior.

El nombre visible es **Formato-Mariategui**, pero el componente técnico sigue siendo `format_flextiles`. Esto permite actualizar cursos existentes, conservar la tabla `format_flextiles_options` y no romper la app Yared.AI.

## Instalación

1. Respaldar la base de datos y el directorio `moodledata` antes de instalar.
2. Instalar primero `format_flexsections` 4.1.7 o superior.
3. Copiar la carpeta `format_flextiles` en `course/format/flextiles` o instalar el ZIP desde *Administración del sitio > Extensiones > Instalar extensiones*.
4. Entrar como administrador y completar la notificación de actualización.
5. En la configuración del curso, elegir **Formato-Mariategui** como formato.

## Uso

- En la portada del curso, las secciones de primer nivel aparecen como mosaicos.
- Al abrir una sección, sus subsecciones aparecen como mosaicos por defecto.
- Cada subsección permite elegir **Mosaico** o **Acordeón** en su formulario de edición. El acordeón muestra las actividades dentro de la sección superior, sin abrir otra página.
- Las secciones de primer nivel siempre son mosaicos; la opción de acordeón no se aplica a ellas.
- Al abrir una subsección, se muestran sus actividades y, si tiene hijas, sus mosaicos.
- La cabecera de la sección ya no muestra la etiqueta **Sección** ni el bloque de descripción. Las actividades siguen debajo; `flextiles-section-badges` es la zona de insignias de Moodle (visibilidad, restricciones, etc.), no la descripción.
- En modo edición se usan los controles habituales de Moodle: **Añadir subsección**, editar sección, mover, ocultar y eliminar. Estos controles están también en la cabecera de las secciones abiertas con `course/view.php?section=...`.
- Cada sección y subsección incluye **Mover hacia arriba** y **Mover hacia abajo** en su menú de acciones. El movimiento respeta el padre: una subsección se reordena dentro de su sección principal y no se convierte en sección de primer nivel.
- Las secciones ocultas o con restricciones muestran una etiqueta y un estilo atenuado para el profesor.
- Cada sección tiene icono, color y URL de imagen opcional en su formulario de edición.
- En la configuración del curso se eligen columnas, resumen, cantidad de elementos y **ancho del contenido** (Estándar 830 px, Amplio 1400 px o Ancho completo). El ancho amplio es el valor por defecto y en móviles/tabletas se mantiene el 100% responsive.

## Conversión desde Flexsections

Al cambiar un curso de **Flexsections** a **Formato-Mariategui**, el plugin copia automáticamente la jerarquía (`parent`), la visibilidad y las demás opciones de sección antes de que Moodle elimine las opciones del formato anterior. Las subsecciones convertidas quedan en modo mosaico por defecto.

## Cambio temporal a otro formato

Formato-Mariategui guarda una copia propia de su jerarquía y de sus opciones de presentación en la tabla `format_flextiles_options`. Moodle elimina las opciones del formato anterior al cambiar de formato; al volver a Formato-Mariategui, esta copia se restaura y el campo `parent` se traduce al número de sección actual. Así se conservan:

- la sección padre de cada subsección;
- el orden de las secciones;
- el modo **Mosaico** o **Acordeón**;
- el color, el icono y la imagen del mosaico;
- el ancho del contenido y el resto de opciones del curso.

Si mientras el curso está en otro formato se elimina una sección, sus hijas se restauran como secciones de primer nivel. Si se renumera una sección, la relación se conserva usando el id guardado.

## Importante

- `mod_subsection` no es necesario para la jerarquía; Formato-Mariategui la construye con secciones de Moodle.
- La imagen de mosaico es una URL pública HTTP(S); no se sube a Moodle.
- El enlace de regreso a la sección en actividades se puede desactivar en la configuración del curso.
- Las copias de seguridad de Moodle conservan el formato, la jerarquía y las opciones de mosaico/acordeón.
- Este paquete está marcado como **BETA**. Probar en un curso de prueba antes de convertir cursos reales.
